#ifndef COVERAGE_ENGINE_HPP
#define COVERAGE_ENGINE_HPP

// ============================================================
//  VC_SIM Phase 2 – Functional Coverage Engine
//  Implements: covergroup, coverpoint, bins, cross-coverage
//  All commercial features: bins, illegal_bins, ignore_bins,
//  cross, goal, option.weight, option.at_least, wildcard bins
// ============================================================

#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <functional>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <cmath>

namespace vcs {

// ──────────────────────────────────────────────
//  BinType: what kind of bin this is
// ──────────────────────────────────────────────
enum class BinType { NORMAL, ILLEGAL, IGNORE, WILDCARD, TRANSITION };

// ──────────────────────────────────────────────
//  CoverageBin: one bin inside a coverpoint
// ──────────────────────────────────────────────
struct CoverageBin {
    std::string name;
    BinType     type     = BinType::NORMAL;
    long long   lo       = 0, hi = 0;    // inclusive range [lo, hi]
    int         hits     = 0;
    int         at_least = 1;            // min hits to be considered covered
    bool        is_transition = false;
    std::vector<std::pair<long long,long long>> transition_values; // prev->next pairs

    CoverageBin(const std::string& n, long long lo_, long long hi_,
                BinType t = BinType::NORMAL, int at_least_ = 1)
        : name(n), type(t), lo(lo_), hi(hi_), at_least((at_least_ < 1) ? 1 : at_least_) {}

    bool matches(long long v) const {
        if (type == BinType::WILDCARD) {
            // Wildcard: lo is the "mask" value, hi is don't-care mask
            return (v & ~hi) == (lo & ~hi);
        }
        return v >= lo && v <= hi;
    }

    bool is_covered() const {
        if (type == BinType::ILLEGAL || type == BinType::IGNORE) return true;
        return hits >= at_least;
    }

    double coverage() const {
        if (type == BinType::ILLEGAL || type == BinType::IGNORE) return 100.0;
        return std::min(100.0, (hits * 100.0) / at_least);
    }
};

// ──────────────────────────────────────────────
//  Coverpoint: named coverage point with bins
// ──────────────────────────────────────────────
struct Coverpoint {
    std::string name;
    std::vector<CoverageBin> bins;
    int illegal_hits = 0;
    double weight = 1.0;
    bool auto_bin_max = false;  // auto_bin_max option
    int auto_bin_count = 64;

    Coverpoint() = default;
    explicit Coverpoint(const std::string& n, double w = 1.0)
        : name(n), weight(w) {}

    // Add a normal bin for a range
    Coverpoint& add_bin(const std::string& n, long long lo, long long hi, int at_least = 1) {
        bins.emplace_back(n, lo, hi, BinType::NORMAL, at_least);
        return *this;
    }
    // Single-value bin
    Coverpoint& add_val_bin(const std::string& n, long long v, int at_least = 1) {
        return add_bin(n, v, v, at_least);
    }
    // Illegal bin
    Coverpoint& add_illegal_bin(const std::string& n, long long lo, long long hi) {
        bins.emplace_back(n, lo, hi, BinType::ILLEGAL);
        return *this;
    }
    // Ignore bin
    Coverpoint& add_ignore_bin(const std::string& n, long long lo, long long hi) {
        bins.emplace_back(n, lo, hi, BinType::IGNORE);
        return *this;
    }
    // Wildcard bin (verilog-style 'x = don't care)
    Coverpoint& add_wildcard_bin(const std::string& n, long long val, long long mask) {
        CoverageBin b(n, val, mask, BinType::WILDCARD);
        bins.push_back(b);
        return *this;
    }

    // Sample a value — updates all matching bins
    void sample(long long value) {
        bool hit_any = false;
        for (auto& b : bins) {
            if (b.matches(value)) {
                if (b.type == BinType::ILLEGAL) {
                    illegal_hits++;
                    std::cerr << "\033[1;31m[COVERAGE] ILLEGAL BIN HIT: "
                              << name << "::" << b.name << " = " << value << "\033[0m\n";
                } else if (b.type != BinType::IGNORE) {
                    b.hits++;
                    hit_any = true;
                }
            }
        }
    }

    // Number of covered bins (normal only)
    int covered_bins() const {
        int c = 0;
        for (const auto& b : bins)
            if (b.type == BinType::NORMAL || b.type == BinType::WILDCARD || b.type == BinType::TRANSITION)
                if (b.is_covered()) c++;
        return c;
    }
    int total_bins() const {
        int t = 0;
        for (const auto& b : bins)
            if (b.type == BinType::NORMAL || b.type == BinType::WILDCARD || b.type == BinType::TRANSITION)
                t++;
        return t;
    }
    double coverage_pct() const {
        int t = total_bins();
        if (t == 0) return 100.0;
        return (covered_bins() * 100.0) / t;
    }
};

// ──────────────────────────────────────────────
//  CrossCoverage: cross of two coverpoints
// ──────────────────────────────────────────────
struct CrossCoverage {
    std::string name;
    std::string cp1_name, cp2_name;
    // key: (bin1_idx, bin2_idx) -> hit count
    std::map<std::pair<int,int>, int> cross_hits;

    CrossCoverage() = default;
    CrossCoverage(const std::string& n, const std::string& a, const std::string& b)
        : name(n), cp1_name(a), cp2_name(b) {}

    void sample(int bin1_idx, int bin2_idx) {
        cross_hits[{bin1_idx, bin2_idx}]++;
    }

    double coverage_pct(const Coverpoint& cp1, const Coverpoint& cp2) const {
        int total = cp1.total_bins() * cp2.total_bins();
        if (total == 0) return 100.0;
        int covered = 0;
        for (int i = 0; i < (int)cp1.bins.size(); i++)
            for (int j = 0; j < (int)cp2.bins.size(); j++) {
                auto it = cross_hits.find({i, j});
                if (it != cross_hits.end() && it->second > 0) covered++;
            }
        return (covered * 100.0) / total;
    }
};

// ──────────────────────────────────────────────
//  Covergroup: named collection of coverpoints
// ──────────────────────────────────────────────
struct Covergroup {
    std::string name;
    std::vector<Coverpoint> coverpoints;
    std::vector<CrossCoverage> crosses;
    double goal = 100.0;   // coverage goal %
    int    sample_count = 0;

    Covergroup() = default;
    explicit Covergroup(const std::string& n, double goal_ = 100.0)
        : name(n), goal(goal_) {}

    Coverpoint& add_coverpoint(const std::string& n, double weight = 1.0) {
        coverpoints.emplace_back(n, weight);
        return coverpoints.back();
    }

    CrossCoverage& add_cross(const std::string& n, const std::string& cp1, const std::string& cp2) {
        crosses.emplace_back(n, cp1, cp2);
        return crosses.back();
    }

    // Sample all coverpoints via a map of name->value
    void sample(const std::map<std::string, long long>& values) {
        sample_count++;
        for (auto& cp : coverpoints) {
            auto it = values.find(cp.name);
            if (it != values.end()) {
                cp.sample(it->second);
                // Update cross coverage
                for (auto& cross : crosses) {
                    if (cross.cp1_name == cp.name || cross.cp2_name == cp.name) {
                        auto it2 = values.find(
                            cross.cp1_name == cp.name ? cross.cp2_name : cross.cp1_name);
                        if (it2 != values.end()) {
                            // Find matching bin indices
                            Coverpoint* cp1_ptr = nullptr;
                            Coverpoint* cp2_ptr = nullptr;
                            for (auto& cpt : coverpoints) {
                                if (cpt.name == cross.cp1_name) cp1_ptr = &cpt;
                                if (cpt.name == cross.cp2_name) cp2_ptr = &cpt;
                            }
                            if (cp1_ptr && cp2_ptr) {
                                int idx1 = -1, idx2 = -1;
                                long long v1 = values.count(cp1_ptr->name) ? values.at(cp1_ptr->name) : 0;
                                long long v2 = values.count(cp2_ptr->name) ? values.at(cp2_ptr->name) : 0;
                                for (int i = 0; i < (int)cp1_ptr->bins.size(); i++)
                                    if (cp1_ptr->bins[i].matches(v1)) { idx1 = i; break; }
                                for (int j = 0; j < (int)cp2_ptr->bins.size(); j++)
                                    if (cp2_ptr->bins[j].matches(v2)) { idx2 = j; break; }
                                if (idx1 >= 0 && idx2 >= 0)
                                    cross.sample(idx1, idx2);
                            }
                        }
                    }
                }
            }
        }
    }

    double coverage_pct() const {
        if (coverpoints.empty()) return 100.0;
        double total_weight = 0, weighted_cov = 0;
        for (const auto& cp : coverpoints) {
            total_weight += cp.weight;
            weighted_cov += cp.weight * cp.coverage_pct();
        }
        return total_weight > 0 ? weighted_cov / total_weight : 100.0;
    }

    bool goal_met() const { return coverage_pct() >= goal; }
};

// ──────────────────────────────────────────────
//  CoverageDatabase: global singleton
//  Collects all covergroups and generates reports
// ──────────────────────────────────────────────
class CoverageDatabase {
    std::vector<Covergroup*> groups_;
    CoverageDatabase() = default;
public:
    static CoverageDatabase& get() {
        static CoverageDatabase inst;
        return inst;
    }

    void register_group(Covergroup* cg) {
        groups_.push_back(cg);
    }

    double total_coverage() const {
        if (groups_.empty()) return 100.0;
        double sum = 0;
        for (const auto* g : groups_) sum += g->coverage_pct();
        return sum / groups_.size();
    }

    // ── Text Report ────────────────────────────
    std::string generate_report() const {
        std::ostringstream oss;
        oss << "\n";
        oss << "╔══════════════════════════════════════════════════════════════════════════════╗\n";
        oss << "║              VC_SIM FUNCTIONAL COVERAGE REPORT (Phase 2)                    ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        oss << std::fixed << std::setprecision(2);
        oss << "║  Overall Functional Coverage : " << std::setw(6) << total_coverage()
            << "%                                        ║\n";
        oss << "║  Total Covergroups           : " << std::setw(6) << groups_.size()
            << "                                         ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";

        for (const auto* cg : groups_) {
            oss << "║  COVERGROUP: " << std::left << std::setw(30) << cg->name
                << "  Coverage: " << std::right << std::setw(6) << cg->coverage_pct() << "%"
                << "  Goal: " << std::setw(6) << cg->goal << "%  ║\n";
            oss << "║  Samples: " << std::setw(8) << cg->sample_count
                << "  Status: " << (cg->goal_met() ? "✓ GOAL MET" : "✗ BELOW GOAL")
                << std::string(26, ' ') << "   ║\n";
            oss << "║  ┌─────────────────────────────┬───────┬───────┬──────────────────┐   ║\n";
            oss << "║  │ Coverpoint                  │ Bins  │ Cvrd  │ Coverage %       │   ║\n";
            oss << "║  ├─────────────────────────────┼───────┼───────┼──────────────────┤   ║\n";
            for (const auto& cp : cg->coverpoints) {
                oss << "║  │ " << std::left << std::setw(28) << cp.name
                    << "│ " << std::right << std::setw(5) << cp.total_bins()
                    << " │ " << std::setw(5) << cp.covered_bins()
                    << " │ ";
                // progress bar
                int bar_len = 16;
                int filled = (int)(cp.coverage_pct() / 100.0 * bar_len);
                oss << "[";
                for (int i = 0; i < bar_len; i++) oss << (i < filled ? "█" : "░");
                oss << "] " << std::setw(5) << std::fixed << std::setprecision(1)
                    << cp.coverage_pct() << "%│   ║\n";

                // Print each bin detail
                for (const auto& b : cp.bins) {
                    std::string btype;
                    switch (b.type) {
                        case BinType::ILLEGAL:    btype = "[ILL]"; break;
                        case BinType::IGNORE:     btype = "[IGN]"; break;
                        case BinType::WILDCARD:   btype = "[WLD]"; break;
                        case BinType::TRANSITION: btype = "[TRN]"; break;
                        default:                  btype = "     "; break;
                    }
                    oss << "║  │   " << btype << " "
                        << std::left << std::setw(20) << b.name
                        << " [" << b.lo << ":" << b.hi << "]"
                        << "  hits=" << b.hits
                        << (b.is_covered() ? " ✓" : " ✗")
                        << "\n";
                }
            }
            oss << "║  └─────────────────────────────┴───────┴───────┴──────────────────┘   ║\n";

            // Cross coverage
            for (const auto& cross : cg->crosses) {
                const Coverpoint* cp1 = nullptr;
                const Coverpoint* cp2 = nullptr;
                for (const auto& cp : cg->coverpoints) {
                    if (cp.name == cross.cp1_name) cp1 = &cp;
                    if (cp.name == cross.cp2_name) cp2 = &cp;
                }
                if (cp1 && cp2) {
                    double cov = cross.coverage_pct(*cp1, *cp2);
                    oss << "║  CROSS: " << cross.name << " (" << cross.cp1_name
                        << " x " << cross.cp2_name << ")  Coverage: "
                        << std::fixed << std::setprecision(2) << cov << "%\n";
                }
            }
            oss << "╠══════════════════════════════════════════════════════════════════════════╣\n";
        }
        oss << "╚══════════════════════════════════════════════════════════════════════════════╝\n";
        return oss.str();
    }

    // ── HTML Report ────────────────────────────
    std::string generate_html_report() const {
        std::ostringstream h;
        h << "<!DOCTYPE html><html><head><title>VC_SIM Coverage Report</title>\n";
        h << "<style>body{font-family:monospace;background:#1e1e2e;color:#cdd6f4;}\n";
        h << "table{border-collapse:collapse;width:100%;}\n";
        h << "th{background:#313244;padding:8px;text-align:left;}\n";
        h << "td{border:1px solid #45475a;padding:6px;}\n";
        h << ".pass{color:#a6e3a1;} .fail{color:#f38ba8;} .warn{color:#f9e2af;}\n";
        h << ".bar-bg{background:#313244;border-radius:4px;height:12px;}\n";
        h << ".bar-fill{background:#89b4fa;border-radius:4px;height:12px;}\n";
        h << "h1{color:#cba6f7;} h2{color:#89b4fa;} h3{color:#94e2d5;}\n";
        h << "</style></head><body>\n";
        h << "<h1>🔬 VC_SIM Functional Coverage Report</h1>\n";
        h << "<p>Overall: <strong>" << std::fixed << std::setprecision(2)
          << total_coverage() << "%</strong></p>\n";

        for (const auto* cg : groups_) {
            h << "<h2>Covergroup: " << cg->name << "</h2>\n";
            h << "<p>Samples: " << cg->sample_count
              << " | Coverage: " << cg->coverage_pct() << "%"
              << " | Goal: " << cg->goal << "% "
              << (cg->goal_met() ? "<span class='pass'>✓ MET</span>"
                                 : "<span class='fail'>✗ NOT MET</span>")
              << "</p>\n";
            h << "<table><tr><th>Coverpoint</th><th>Total Bins</th><th>Covered</th><th>Coverage</th><th>Progress</th></tr>\n";
            for (const auto& cp : cg->coverpoints) {
                int pct = (int)cp.coverage_pct();
                h << "<tr><td>" << cp.name << "</td><td>" << cp.total_bins()
                  << "</td><td>" << cp.covered_bins()
                  << "</td><td class='" << (pct==100 ? "pass" : pct>50 ? "warn" : "fail") << "'>"
                  << pct << "%</td>"
                  << "<td><div class='bar-bg'><div class='bar-fill' style='width:"
                  << pct << "%'></div></div></td></tr>\n";
            }
            h << "</table>\n";
        }
        h << "</body></html>\n";
        return h.str();
    }

    void write_html_report(const std::string& path) const {
        std::ofstream f(path);
        if (f.is_open()) {
            f << generate_html_report();
            std::cout << "[COVERAGE] HTML report written to: " << path << "\n";
        }
    }
};

} // namespace vcs
#endif // COVERAGE_ENGINE_HPP

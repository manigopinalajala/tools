#ifndef CODE_COVERAGE_HPP
#define CODE_COVERAGE_HPP

// ============================================================
//  VC_SIM Phase 2 – Code Coverage Instrumentation Engine
//  Implements: Statement, Branch, Toggle, Expression, FSM coverage
//  Inserted automatically by the codegen for every translated block
// ============================================================

#include <string>
#include <map>
#include <set>
#include <vector>
#include <unordered_map>
#include <sstream>
#include <iomanip>
#include <iostream>
#include <fstream>

namespace vcs {

// ──────────────────────────────────────────────
//  StatementCoverage: tracks which source lines were executed
// ──────────────────────────────────────────────
struct StatementPoint {
    std::string file;
    int         line;
    int         hits = 0;
    std::string label;  // optional human-readable label

    bool is_covered() const { return hits > 0; }
};

// ──────────────────────────────────────────────
//  BranchCoverage: tracks true/false arms of if/case
// ──────────────────────────────────────────────
struct BranchPoint {
    std::string file;
    int         line;
    std::string label;
    int         true_hits  = 0;
    int         false_hits = 0;

    bool both_covered() const { return true_hits > 0 && false_hits > 0; }
};

// ──────────────────────────────────────────────
//  ToggleCoverage: each signal gets 0→1 and 1→0 tracking
// ──────────────────────────────────────────────
struct TogglePoint {
    std::string signal_name;
    int         width = 1;
    int         rise_hits = 0;   // 0→1 transitions
    int         fall_hits = 0;   // 1→0 transitions
    long long   last_value = -1; // uninitialized sentinel

    void record(long long new_val) {
        if (last_value < 0) { last_value = new_val; return; }
        // Check each bit
        long long diff = last_value ^ new_val;
        for (int b = 0; b < width; b++) {
            if ((diff >> b) & 1) {
                if ((new_val >> b) & 1) rise_hits++;
                else                    fall_hits++;
            }
        }
        last_value = new_val;
    }

    double coverage_pct() const {
        int total_expected = width * 2; // rise + fall for each bit
        int covered = 0;
        if (rise_hits > 0) covered += width;
        if (fall_hits > 0) covered += width;
        return total_expected > 0 ? (covered * 100.0) / total_expected : 100.0;
    }
};

// ──────────────────────────────────────────────
//  ExpressionCoverage: tracks each sub-expression true/false
// ──────────────────────────────────────────────
struct ExpressionPoint {
    std::string file;
    int         line;
    std::string expr_text;
    int         true_hits  = 0;
    int         false_hits = 0;

    void record(bool result) {
        if (result) true_hits++;
        else        false_hits++;
    }

    bool is_covered() const { return true_hits > 0 && false_hits > 0; }
    double coverage_pct() const {
        int covered = (true_hits > 0 ? 1 : 0) + (false_hits > 0 ? 1 : 0);
        return covered * 50.0;
    }
};

// ──────────────────────────────────────────────
//  FSM State Coverage: tracks state machine transitions
// ──────────────────────────────────────────────
struct FSMPoint {
    std::string name;
    std::set<long long> all_states;
    std::set<long long> visited_states;
    std::map<std::pair<long long,long long>, int> transition_hits;
    long long last_state = -1;

    void register_state(long long s) { all_states.insert(s); }

    void record_state(long long s) {
        visited_states.insert(s);
        if (last_state >= 0 && last_state != s) {
            transition_hits[{last_state, s}]++;
        }
        last_state = s;
    }

    double state_coverage_pct() const {
        if (all_states.empty()) return 100.0;
        return (visited_states.size() * 100.0) / all_states.size();
    }
};

// ──────────────────────────────────────────────
//  CodeCoverageDB: global singleton for all coverage types
// ──────────────────────────────────────────────
class CodeCoverageDB {
    std::vector<StatementPoint>  statements_;
    std::vector<BranchPoint>     branches_;
    std::map<std::string, TogglePoint>    toggles_;
    std::vector<ExpressionPoint> expressions_;
    std::map<std::string, FSMPoint>       fsms_;

    CodeCoverageDB() = default;
public:
    static CodeCoverageDB& get() {
        static CodeCoverageDB inst;
        return inst;
    }

    // ── Statement Coverage ─────────────────────
    int add_statement(const std::string& file, int line, const std::string& lbl = "") {
        int id = (int)statements_.size();
        statements_.push_back({file, line, 0, lbl});
        return id;
    }
    void hit_statement(int id) {
        if (id >= 0 && id < (int)statements_.size())
            statements_[id].hits++;
    }

    // ── Branch Coverage ────────────────────────
    int add_branch(const std::string& file, int line, const std::string& lbl = "") {
        int id = (int)branches_.size();
        branches_.push_back({file, line, lbl});
        return id;
    }
    void hit_branch(int id, bool taken) {
        if (id < 0 || id >= (int)branches_.size()) return;
        if (taken) branches_[id].true_hits++;
        else       branches_[id].false_hits++;
    }

    // ── Toggle Coverage ────────────────────────
    void add_toggle(const std::string& sig, int width = 1) {
        toggles_[sig].signal_name = sig;
        toggles_[sig].width = width;
    }
    void record_toggle(const std::string& sig, long long val) {
        auto it = toggles_.find(sig);
        if (it != toggles_.end()) it->second.record(val);
    }

    // ── Expression Coverage ────────────────────
    int add_expression(const std::string& file, int line, const std::string& expr) {
        int id = (int)expressions_.size();
        expressions_.push_back({file, line, expr});
        return id;
    }
    void record_expression(int id, bool result) {
        if (id >= 0 && id < (int)expressions_.size())
            expressions_[id].record(result);
    }

    // ── FSM Coverage ───────────────────────────
    void add_fsm(const std::string& name, const std::vector<long long>& states) {
        fsms_[name].name = name;
        for (auto s : states) fsms_[name].register_state(s);
    }
    void record_fsm_state(const std::string& name, long long state) {
        auto it = fsms_.find(name);
        if (it != fsms_.end()) it->second.record_state(state);
    }

    // ── Metrics ────────────────────────────────
    double statement_coverage() const {
        if (statements_.empty()) return 100.0;
        int covered = 0;
        for (const auto& s : statements_) if (s.is_covered()) covered++;
        return (covered * 100.0) / statements_.size();
    }

    double branch_coverage() const {
        if (branches_.empty()) return 100.0;
        int covered = 0, total = (int)branches_.size() * 2;
        for (const auto& b : branches_) {
            if (b.true_hits  > 0) covered++;
            if (b.false_hits > 0) covered++;
        }
        return (covered * 100.0) / total;
    }

    double toggle_coverage() const {
        if (toggles_.empty()) return 100.0;
        double sum = 0;
        for (const auto& kv : toggles_) sum += kv.second.coverage_pct();
        return sum / toggles_.size();
    }

    double expression_coverage() const {
        if (expressions_.empty()) return 100.0;
        double sum = 0;
        for (const auto& e : expressions_) sum += e.coverage_pct();
        return sum / expressions_.size();
    }

    double fsm_state_coverage() const {
        if (fsms_.empty()) return 100.0;
        double sum = 0;
        for (const auto& kv : fsms_) sum += kv.second.state_coverage_pct();
        return sum / fsms_.size();
    }

    double overall_code_coverage() const {
        int count = 0;
        double sum = 0;
        if (!statements_.empty()) { sum += statement_coverage();  count++; }
        if (!branches_.empty())   { sum += branch_coverage();     count++; }
        if (!toggles_.empty())    { sum += toggle_coverage();     count++; }
        if (!expressions_.empty()){ sum += expression_coverage(); count++; }
        if (!fsms_.empty())       { sum += fsm_state_coverage();  count++; }
        return count > 0 ? sum / count : 100.0;
    }

    // ── Text Report ────────────────────────────
    std::string generate_report() const {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(2);
        oss << "\n";
        oss << "╔══════════════════════════════════════════════════════════════════════════════╗\n";
        oss << "║              VC_SIM CODE COVERAGE REPORT (Phase 2)                          ║\n";
        oss << "╠════════════════════════════════════════╦═════════════════════════════════════╣\n";
        oss << "║  Coverage Type                         ║  Coverage %                        ║\n";
        oss << "╠════════════════════════════════════════╬═════════════════════════════════════╣\n";
        auto row = [&](const std::string& name, double pct, int covered, int total) {
            oss << "║  " << std::left << std::setw(38) << name << "║  ";
            int bar = (int)(pct / 100.0 * 24);
            oss << "[";
            for (int i = 0; i < 24; i++) oss << (i < bar ? "█" : "░");
            oss << "] " << std::right << std::setw(6) << pct << "% ("
                << covered << "/" << total << ")" << "  ║\n";
        };

        if (!statements_.empty()) {
            int covered = 0;
            for (const auto& s : statements_) if (s.is_covered()) covered++;
            row("Statement Coverage", statement_coverage(), covered, (int)statements_.size());
        } else {
            row("Statement Coverage", 100.0, 0, 0);
        }

        if (!branches_.empty()) {
            int covered = 0, total = (int)branches_.size() * 2;
            for (const auto& b : branches_) {
                if (b.true_hits > 0) covered++;
                if (b.false_hits > 0) covered++;
            }
            row("Branch Coverage (T/F)", branch_coverage(), covered, total);
        } else {
            row("Branch Coverage (T/F)", 100.0, 0, 0);
        }

        if (!toggles_.empty()) {
            int covered = 0, total = 0;
            for (const auto& kv : toggles_) {
                total += kv.second.width * 2;
                if (kv.second.rise_hits > 0) covered += kv.second.width;
                if (kv.second.fall_hits > 0) covered += kv.second.width;
            }
            row("Toggle Coverage (0→1/1→0)", toggle_coverage(), covered, total);
        } else {
            row("Toggle Coverage (0→1/1→0)", 100.0, 0, 0);
        }

        if (!expressions_.empty()) {
            int covered = 0;
            for (const auto& e : expressions_) if (e.is_covered()) covered++;
            row("Expression Coverage (T+F)", expression_coverage(), covered, (int)expressions_.size());
        } else {
            row("Expression Coverage (T+F)", 100.0, 0, 0);
        }

        if (!fsms_.empty()) {
            int covered = 0, total = 0;
            for (const auto& kv : fsms_) {
                total += (int)kv.second.all_states.size();
                covered += (int)kv.second.visited_states.size();
            }
            row("FSM State Coverage", fsm_state_coverage(), covered, total);
        } else {
            row("FSM State Coverage", 100.0, 0, 0);
        }

        oss << "╠════════════════════════════════════════╬═════════════════════════════════════╣\n";
        row("OVERALL CODE COVERAGE", overall_code_coverage(),
            (int)overall_code_coverage(), 100);
        oss << "╚════════════════════════════════════════╩═════════════════════════════════════╝\n";

        // Toggle detail
        if (!toggles_.empty()) {
            oss << "\nToggle Detail:\n";
            for (const auto& kv : toggles_) {
                const auto& t = kv.second;
                oss << "  " << std::left << std::setw(30) << t.signal_name
                    << " Rise=" << t.rise_hits << "  Fall=" << t.fall_hits
                    << "  " << t.coverage_pct() << "%\n";
            }
        }
        return oss.str();
    }
};

// ──────────────────────────────────────────────
//  RAII helper for branch coverage instrumentation
// ──────────────────────────────────────────────
struct BranchTracker {
    int id_;
    bool result_;
    BranchTracker(int id, bool result) : id_(id), result_(result) {
        CodeCoverageDB::get().hit_branch(id, result);
    }
    operator bool() const { return result_; }
};

// Macro wrappers for instrumented code
#define COV_STMT(file, line)  vcs::CodeCoverageDB::get().hit_statement( \
    vcs::CodeCoverageDB::get().add_statement(file, line))

#define COV_BRANCH(file, line, cond) \
    vcs::BranchTracker(vcs::CodeCoverageDB::get().add_branch(file, line), (cond))

#define COV_TOGGLE(sig, val, width) \
    do { vcs::CodeCoverageDB::get().add_toggle(sig, width); \
         vcs::CodeCoverageDB::get().record_toggle(sig, val); } while(0)

} // namespace vcs
#endif // CODE_COVERAGE_HPP

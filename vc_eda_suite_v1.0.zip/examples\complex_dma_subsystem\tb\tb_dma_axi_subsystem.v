// =============================================================================
// File: tb_dma_axi_subsystem.v
// Module: tb_dma_axi_subsystem
// Description: Comprehensive Commercial-Grade Testbench for the Complex DMA
//              and AXI4-Lite SoC Subsystem.
// Features:
//   - AXI-Lite Master BFM tasks (Write, Read, Response verification)
//   - SRAM Direct Access & Byte-Strobe Verification
//   - Multi-Burst DMA Engine Execution
//   - Parallel CRC-32 Hardware Acceleration Verification
//   - Synchronous FIFO Drain & Watermark Checks
//   - Interrupt Masking & Write-1-to-Clear Handling
//   - Complete VCD Waveform Generation ($dumpvars)
// =============================================================================

`timescale 1ns / 1ps

module tb_dma_axi_subsystem;

    // Clock and Reset Signals
    reg         clk;
    reg         resetn;

    // AXI4-Lite Master Signals
    reg  [31:0] s_axi_awaddr;
    reg         s_axi_awvalid;
    wire        s_axi_awready;

    reg  [31:0] s_axi_wdata;
    reg  [3:0]  s_axi_wstrb;
    reg         s_axi_wvalid;
    wire        s_axi_wready;

    wire [1:0]  s_axi_bresp;
    wire        s_axi_bvalid;
    reg         s_axi_bready;

    reg  [31:0] s_axi_araddr;
    reg         s_axi_arvalid;
    wire        s_axi_arready;

    wire [31:0] s_axi_rdata;
    wire [1:0]  s_axi_rresp;
    wire        s_axi_rvalid;
    reg         s_axi_rready;

    // External FIFO Interface Signals
    reg         ext_fifo_rd_en;
    wire [31:0] ext_fifo_rd_data;
    wire        ext_fifo_empty;
    wire        ext_fifo_almost_empty;

    // External Arbiter Request/Grant
    reg  [1:0]  ext_arb_req;
    wire [1:0]  ext_arb_grant;

    // Interrupt Output
    wire        irq_out;

    // Verification Tracking Variables
    integer error_count;
    integer test_step;
    reg [31:0] read_val;

    // -------------------------------------------------------------------------
    // Device Under Test (DUT) Instantiation
    // -------------------------------------------------------------------------
    dma_axi_subsystem_top dut (
        .clk                   (clk),
        .resetn                (resetn),
        
        .s_axi_awaddr          (s_axi_awaddr),
        .s_axi_awvalid         (s_axi_awvalid),
        .s_axi_awready         (s_axi_awready),
        
        .s_axi_wdata           (s_axi_wdata),
        .s_axi_wstrb           (s_axi_wstrb),
        .s_axi_wvalid          (s_axi_wvalid),
        .s_axi_wready          (s_axi_wready),
        
        .s_axi_bresp           (s_axi_bresp),
        .s_axi_bvalid          (s_axi_bvalid),
        .s_axi_bready          (s_axi_bready),
        
        .s_axi_araddr          (s_axi_araddr),
        .s_axi_arvalid         (s_axi_arvalid),
        .s_axi_arready         (s_axi_arready),
        
        .s_axi_rdata           (s_axi_rdata),
        .s_axi_rresp           (s_axi_rresp),
        .s_axi_rvalid          (s_axi_rvalid),
        .s_axi_rready          (s_axi_rready),
        
        .ext_fifo_rd_en        (ext_fifo_rd_en),
        .ext_fifo_rd_data      (ext_fifo_rd_data),
        .ext_fifo_empty        (ext_fifo_empty),
        .ext_fifo_almost_empty (ext_fifo_almost_empty),
        
        .ext_arb_req           (ext_arb_req),
        .ext_arb_grant         (ext_arb_grant),
        
        .irq_out               (irq_out)
    );

    // -------------------------------------------------------------------------
    // 100 MHz Clock Generator (Period = 10ns)
    // -------------------------------------------------------------------------
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // -------------------------------------------------------------------------
    // AXI-Lite Bus Master Tasks
    // -------------------------------------------------------------------------
    task axi_write;
        input [31:0] addr;
        input [31:0] data;
        input [3:0]  strb;
        begin
            @(posedge clk);
            s_axi_awaddr  <= addr;
            s_axi_awvalid <= 1'b1;
            s_axi_wdata   <= data;
            s_axi_wstrb   <= strb;
            s_axi_wvalid  <= 1'b1;
            s_axi_bready  <= 1'b1;

            // Wait for write address and write data acknowledgement
            wait (s_axi_awready && s_axi_wready);
            @(posedge clk);
            s_axi_awvalid <= 1'b0;
            s_axi_wvalid  <= 1'b0;

            // Wait for response handshake
            wait (s_axi_bvalid);
            @(posedge clk);
            s_axi_bready  <= 1'b0;
            #2;
        end
    endtask

    task axi_read;
        input  [31:0] addr;
        output [31:0] data;
        begin
            @(posedge clk);
            s_axi_araddr  <= addr;
            s_axi_arvalid <= 1'b1;
            s_axi_rready  <= 1'b1;

            // Wait for read address acknowledgement
            wait (s_axi_arready);
            @(posedge clk);
            s_axi_arvalid <= 1'b0;

            // Wait for read data valid
            wait (s_axi_rvalid);
            data = s_axi_rdata;
            @(posedge clk);
            s_axi_rready  <= 1'b0;
            #2;
        end
    endtask

    // -------------------------------------------------------------------------
    // Main Verification Test Suite
    // -------------------------------------------------------------------------
    initial begin
        // Setup Waveform Dumping
        $dumpfile("dma_subsystem.vcd");
        $dumpvars(0, tb_dma_axi_subsystem);

        $display("\n================================================================================");
        $display("   STARTING COMPLEX DMA & AXI4-LITE SUBSYSTEM VERIFICATION SUITE");
        $display("================================================================================");

        // Initialize signals
        error_count    = 0;
        test_step      = 0;
        resetn         = 1'b0;
        s_axi_awaddr   = 32'd0;
        s_axi_awvalid  = 1'b0;
        s_axi_wdata    = 32'd0;
        s_axi_wstrb    = 4'd0;
        s_axi_bready   = 1'b0;
        s_axi_araddr   = 32'd0;
        s_axi_arvalid  = 1'b0;
        s_axi_rready   = 1'b0;
        ext_fifo_rd_en = 1'b0;
        ext_arb_req    = 2'b00;

        // Reset Pulse
        #25;
        @(posedge clk);
        resetn = 1'b1;
        $display("[TIME: %0t ns] Reset deasserted successfully. DUT active.", $time);

        // ---------------------------------------------------------------------
        // TEST 1: Register Bank Read/Write Access & Control Verification
        // ---------------------------------------------------------------------
        test_step = 1;
        $display("\n--- [TEST %0d]: AXI-Lite Register Access & Identification ---", test_step);
        axi_read(32'h0000_0000, read_val);
        $display("  Read CTRL register: 0x%08X (Expected: 0xA5A50000)", read_val);
        if (read_val !== 32'hA5A5_0000) begin
            $display("  [ERROR] CTRL register mismatch!");
            error_count = error_count + 1;
        end

        // Configure Interrupt Mask (Enable DMA Complete IRQ [0] and CRC IRQ [3])
        axi_write(32'h0000_0014, 32'h0000_0009, 4'b1111);
        axi_read(32'h0000_0014, read_val);
        $display("  Read IMR register:  0x%08X (Expected: 0x00000009)", read_val);
        if (read_val !== 32'h0000_0009) begin
            $display("  [ERROR] IMR register configuration mismatch!");
            error_count = error_count + 1;
        end

        // ---------------------------------------------------------------------
        // TEST 2: Direct Dual-Port SRAM Write & Readback via Port A
        // ---------------------------------------------------------------------
        test_step = 2;
        $display("\n--- [TEST %0d]: Dual-Port SRAM Direct Write & Readback ---", test_step);
        // Write pattern into SRAM addresses 0..3 (Offset 0x1000..0x100C)
        axi_write(32'h0000_1000, 32'h1122_3344, 4'b1111);
        axi_write(32'h0000_1004, 32'h5566_7788, 4'b1111);
        axi_write(32'h0000_1008, 32'h99AA_BBCC, 4'b1111);
        axi_write(32'h0000_100C, 32'hDDEE_FF00, 4'b1111);

        // Readback and verify
        axi_read(32'h0000_1000, read_val);
        $display("  SRAM[0] readback: 0x%08X (Expected: 0x11223344)", read_val);
        if (read_val !== 32'h1122_3344) error_count = error_count + 1;

        axi_read(32'h0000_1004, read_val);
        $display("  SRAM[1] readback: 0x%08X (Expected: 0x55667788)", read_val);
        if (read_val !== 32'h5566_7788) error_count = error_count + 1;

        axi_read(32'h0000_1008, read_val);
        $display("  SRAM[2] readback: 0x%08X (Expected: 0x99AABBCC)", read_val);
        if (read_val !== 32'h99AA_BBCC) error_count = error_count + 1;

        axi_read(32'h0000_100C, read_val);
        $display("  SRAM[3] readback: 0x%08X (Expected: 0xDDEEFF00)", read_val);
        if (read_val !== 32'hDDEE_FF00) error_count = error_count + 1;

        // ---------------------------------------------------------------------
        // TEST 3: Initialize Hardware CRC-32 Accelerator
        // ---------------------------------------------------------------------
        test_step = 3;
        $display("\n--- [TEST %0d]: CRC-32 Engine Initialization ---", test_step);
        // Write CRC Seed = 0xFFFFFFFF
        axi_write(32'h0000_0010, 32'hFFFF_FFFF, 4'b1111);
        // Assert CRC Init Pulse (Bit 2 of CTRL register)
        axi_write(32'h0000_0000, 32'h0000_0004, 4'b1111);
        @(posedge clk);

        // ---------------------------------------------------------------------
        // TEST 4: DMA Autonomous Burst Transfer (SRAM -> FIFO & CRC)
        // ---------------------------------------------------------------------
        test_step = 4;
        $display("\n--- [TEST %0d]: DMA Autonomous Burst Transfer ---", test_step);
        // Set Source Address = 0 (SRAM index 0)
        axi_write(32'h0000_0008, 32'h0000_0000, 4'b1111);
        // Set Transfer Length = 4 words
        axi_write(32'h0000_000C, 32'h0000_0004, 4'b1111);
        // Trigger DMA Start (Bit 0 of CTRL register)
        $display("  Triggering DMA Start command...");
        axi_write(32'h0000_0000, 32'h0000_0001, 4'b1111);

        // Poll Status register until DMA completes
        read_val = 32'h0000_0001; // Busy
        while (read_val[0] == 1'b1 || read_val[1] == 1'b0) begin
            axi_read(32'h0000_0004, read_val);
            $display("  Polling STATUS register: 0x%08X (Busy=%b, Done=%b)", read_val, read_val[0], read_val[1]);
            #20;
        end
        $display("  [SUCCESS] DMA Transfer Completed! Transferred words: %0d", read_val[15:8]);

        // ---------------------------------------------------------------------
        // TEST 5: Verify Interrupt Generation and Clear
        // ---------------------------------------------------------------------
        test_step = 5;
        $display("\n--- [TEST %0d]: Interrupt Controller Verification ---", test_step);
        $display("  Master IRQ Pin Level: %b (Expected: 1'b1)", irq_out);
        if (irq_out !== 1'b1) begin
            $display("  [ERROR] Expected irq_out to be HIGH!");
            error_count = error_count + 1;
        end

        // Read ISR (Interrupt Status)
        axi_read(32'h0000_0018, read_val);
        $display("  Read ISR register: 0x%08X (Pending=%b, Raw=%b)", read_val, read_val[7:4], read_val[3:0]);

        // Clear DMA Done Interrupt (Write-1 to Bit 0)
        $display("  Clearing DMA interrupt via Write-1-to-Clear...");
        axi_write(32'h0000_0018, 32'h0000_0001, 4'b1111);
        #10;
        $display("  Master IRQ Pin Level after Clear: %b (Expected: 1'b0)", irq_out);
        if (irq_out !== 1'b0) begin
            $display("  [ERROR] irq_out failed to deassert after clearance!");
            error_count = error_count + 1;
        end

        // ---------------------------------------------------------------------
        // TEST 6: FIFO Stream Readback & Verification
        // ---------------------------------------------------------------------
        test_step = 6;
        $display("\n--- [TEST %0d]: Synchronous FIFO Stream Drain ---", test_step);
        // Check FIFO occupancy register
        axi_read(32'h0000_001C, read_val);
        $display("  FIFO Occupancy: %0d words stored", read_val[4:0]);

        // Pop all 4 words from external FIFO read port
        while (!ext_fifo_empty) begin
            @(posedge clk);
            ext_fifo_rd_en = 1'b1;
            @(posedge clk);
            $display("  [FIFO POP] Popped word: 0x%08X", ext_fifo_rd_data);
            ext_fifo_rd_en = 1'b0;
        end
        $display("  [SUCCESS] All data drained from FIFO. Empty flag: %b", ext_fifo_empty);

        // ---------------------------------------------------------------------
        // TEST 7: Hardware CRC-32 Result Verification
        // ---------------------------------------------------------------------
        test_step = 7;
        $display("\n--- [TEST %0d]: Hardware CRC-32 Accelerator Checksum ---", test_step);
        axi_read(32'h0000_0010, read_val);
        $display("  Computed CRC-32: 0x%08X", read_val);
        if (read_val == 32'h0000_0000 || read_val == 32'hFFFF_FFFF) begin
            $display("  [ERROR] CRC result seems uninitialized or invalid!");
            error_count = error_count + 1;
        end else begin
            $display("  [SUCCESS] CRC-32 accelerator computed valid non-trivial checksum!");
        end

        // ---------------------------------------------------------------------
        // TEST 8: Multi-Master Round-Robin Arbiter Fair Scheduling
        // ---------------------------------------------------------------------
        test_step = 8;
        $display("\n--- [TEST %0d]: Round-Robin Arbiter Fair Scheduling ---", test_step);
        ext_arb_req = 2'b11; // Request both External Ch2 and Ch3
        @(posedge clk);
        #1;
        $display("  External Requests: 2'b11 -> Grants: 2'b%b", ext_arb_grant);
        @(posedge clk);
        #1;
        $display("  Next Cycle Rotating Grants: 2'b%b", ext_arb_grant);
        ext_arb_req = 2'b00;

        // ---------------------------------------------------------------------
        // Final Summary
        // ---------------------------------------------------------------------
        #50;
        $display("\n================================================================================");
        if (error_count == 0) begin
            $display("   *** TEST SUITE PASSED *** (0 Errors, All 8 Test Scenarios Passed)");
            $display("================================================================================\n");
        end else begin
            $display("   *** TEST SUITE FAILED *** (%0d Errors Detected)", error_count);
            $display("================================================================================\n");
        end

        $finish;
    end

endmodule

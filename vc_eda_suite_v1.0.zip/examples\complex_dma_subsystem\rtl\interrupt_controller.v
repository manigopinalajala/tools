// =============================================================================
// File: interrupt_controller.v
// Module: interrupt_controller
// Description: Multi-source Interrupt Controller with status, mask, pending,
//              and clear registers, driving a consolidated level/edge IRQ output.
// =============================================================================

`timescale 1ns / 1ps

module interrupt_controller #(
    parameter NUM_IRQS = 4
)(
    input  wire                clk,
    input  wire                resetn,
    
    // Raw Interrupt Events
    input  wire [NUM_IRQS-1:0] irq_sources, // [0]: DMA Done, [1]: DMA Error, [2]: FIFO Flag, [3]: CRC Done
    
    // Register Interface
    input  wire [NUM_IRQS-1:0] imr_write_data, // Interrupt Mask Write
    input  wire                imr_we,
    input  wire [NUM_IRQS-1:0] isr_clear_data, // Write-1-to-Clear
    input  wire                isr_clear_we,
    
    // Register Readbacks
    output reg  [NUM_IRQS-1:0] imr,             // 1 = unmasked, 0 = masked
    output reg  [NUM_IRQS-1:0] isr,             // Raw latched status
    output wire [NUM_IRQS-1:0] ipr,             // Active Pending (isr & imr)
    
    // Master Aggregated IRQ Output
    output wire                irq_out
);

    assign ipr     = isr & imr;
    assign irq_out = |ipr;

    // Edge-detection registers for pulse inputs
    reg [NUM_IRQS-1:0] irq_sources_d;
    wire [NUM_IRQS-1:0] irq_pulse = irq_sources & ~irq_sources_d;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            irq_sources_d <= {NUM_IRQS{1'b0}};
            isr           <= {NUM_IRQS{1'b0}};
            imr           <= {NUM_IRQS{1'b0}};
        end else begin
            irq_sources_d <= irq_sources;

            // Update Mask Register
            if (imr_we) begin
                imr <= imr_write_data;
            end

            // Latch new interrupt events and handle Write-1-to-Clear
            isr <= (isr | irq_pulse | irq_sources) & ~(isr_clear_we ? isr_clear_data : {NUM_IRQS{1'b0}});
        end
    end

endmodule

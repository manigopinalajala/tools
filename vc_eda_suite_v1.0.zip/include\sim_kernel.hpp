#ifndef SIM_KERNEL_HPP
#define SIM_KERNEL_HPP

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <functional>
#include <string>
#include <memory>
#include <cstdint>

namespace vcs {

class SimulationEngine;

// Event synchronization primitive (->e, @e)
class SimEvent {
public:
    std::string name;
    std::vector<std::function<void()>> waiters;

    SimEvent(const std::string& n = "event") : name(n) {}

    void trigger();
    void add_waiter(std::function<void()> cb) {
        waiters.push_back(cb);
    }
};

// Scheduled event in the discrete event priority queue
struct EventItem {
    double time;
    uint32_t delta;
    uint64_t step_id;
    std::function<void()> action;

    bool operator>(const EventItem& other) const {
        if (time != other.time) return time > other.time;
        if (delta != other.delta) return delta > other.delta;
        return step_id > other.step_id;
    }
};

class SimulationEngine {
public:
    double current_time = 0.0;
    uint32_t delta_cycle = 0;
    uint64_t step_counter = 0;
    bool stop_requested = false;
    bool is_running = false;

    std::priority_queue<EventItem, std::vector<EventItem>, std::greater<EventItem>> event_queue;

    static SimulationEngine& get() {
        static SimulationEngine instance;
        return instance;
    }

    void reset() {
        current_time = 0.0;
        delta_cycle = 0;
        step_counter = 0;
        stop_requested = false;
        is_running = false;
        while (!event_queue.empty()) event_queue.pop();
    }

    void schedule(double delay, std::function<void()> action) {
        double target_time = current_time + (delay < 0 ? 0 : delay);
        uint32_t target_delta = (delay == 0) ? delta_cycle + 1 : 0;
        step_counter++;
        event_queue.push({target_time, target_delta, step_counter, action});
    }

    void run(double max_time = -1.0) {
        is_running = true;
        stop_requested = false;

        while (!event_queue.empty() && !stop_requested) {
            EventItem item = event_queue.top();

            if (max_time >= 0.0 && item.time > max_time) {
                current_time = max_time;
                break;
            }

            event_queue.pop();
            current_time = item.time;
            delta_cycle = item.delta;

            if (item.action) {
                item.action();
            }
        }
        is_running = false;
    }

    void stop() {
        stop_requested = true;
    }
};

inline void SimEvent::trigger() {
    auto w = std::move(waiters);
    waiters.clear();
    for (auto& cb : w) {
        SimulationEngine::get().schedule(0, cb);
    }
}

// Logic / Wire / Signal primitive
class Signal {
public:
    std::string name;
    uint32_t width;
    uint64_t value;
    uint64_t mask;
    SimEvent posedge_event;
    SimEvent negedge_event;
    SimEvent change_event;
    std::vector<std::function<void(uint64_t, uint64_t)>> callbacks;

    Signal(const std::string& n = "sig", uint32_t w = 1, uint64_t def = 0)
        : name(n), width(w), value(def), posedge_event(n + "_posedge"),
          negedge_event(n + "_negedge"), change_event(n + "_change") {
        mask = (w >= 64) ? ~0ULL : ((1ULL << w) - 1);
        value &= mask;
    }

    void set(uint64_t new_val) {
        uint64_t masked = new_val & mask;
        if (masked != value) {
            uint64_t old_val = value;
            value = masked;

            change_event.trigger();
            if ((old_val & 1) == 0 && (masked & 1) == 1) posedge_event.trigger();
            if ((old_val & 1) == 1 && (masked & 1) == 0) negedge_event.trigger();

            for (auto& cb : callbacks) cb(old_val, masked);
        }
    }

    uint64_t get() const { return value; }
    operator uint64_t() const { return value; }
};

// Standard VCD Waveform Dumper
class VcdDumper {
public:
    std::ofstream file;
    bool is_open = false;
    double last_time = -1.0;
    struct TraceVar {
        std::string name;
        uint32_t width;
        std::string id;
        uint64_t last_val;
    };
    std::vector<TraceVar> vars;

    static VcdDumper& get() {
        static VcdDumper inst;
        return inst;
    }

    void open(const std::string& filename = "dump.vcd") {
        file.open(filename);
        is_open = file.is_open();
    }

    void register_var(const std::string& name, uint32_t width, const std::string& id) {
        vars.push_back({name, width, id, 0});
    }

    std::string embedded_rtl_snapshot;

    void embed_rtl_snapshot(const std::string& snapshot_data) {
        embedded_rtl_snapshot = snapshot_data;
    }

    void embed_rtl_files(const std::vector<std::string>& files) {
        std::ostringstream ss;
        ss << "{\n  \"files\": [\n";
        bool first = true;
        for (const auto& fp : files) {
            std::ifstream rf(fp);
            if (!rf.is_open()) continue;
            if (!first) ss << ",\n";
            first = false;
            ss << "    {\n      \"path\": \"" << fp << "\",\n      \"content\": \"";
            std::string rline;
            bool first_rline = true;
            while (std::getline(rf, rline)) {
                if (!first_rline) ss << "\\n";
                first_rline = false;
                for (char c : rline) {
                    if (c == '\\') ss << "\\\\";
                    else if (c == '"') ss << "\\\"";
                    else if (c == '\r') continue;
                    else ss << c;
                }
            }
            ss << "\"\n    }";
        }
        ss << "\n  ]\n}";
        embedded_rtl_snapshot = ss.str();
    }

    void embed_rtl_filelist(const std::string& filelist_path) {
        std::ifstream fl(filelist_path);
        if (!fl.is_open()) return;
        std::ostringstream ss;
        ss << "{\n  \"filelist\": \"" << filelist_path << "\",\n  \"files\": [\n";
        std::string line;
        bool first = true;
        std::string base_dir = "";
        size_t last_slash = filelist_path.find_last_of("/\\");
        if (last_slash != std::string::npos) {
            base_dir = filelist_path.substr(0, last_slash + 1);
        }
        while (std::getline(fl, line)) {
            line.erase(0, line.find_first_not_of(" \t\r\n"));
            line.erase(line.find_last_not_of(" \t\r\n") + 1);
            if (line.empty() || line[0] == '#' || (line.size() >= 2 && line[0] == '/' && line[1] == '/') || line[0] == '+') continue;
            std::string full_path = base_dir + line;
            std::ifstream rf(full_path);
            if (!rf.is_open()) continue;
            if (!first) ss << ",\n";
            first = false;
            ss << "    {\n      \"path\": \"" << line << "\",\n      \"content\": \"";
            std::string rline;
            bool first_rline = true;
            while (std::getline(rf, rline)) {
                if (!first_rline) ss << "\\n";
                first_rline = false;
                for (char c : rline) {
                    if (c == '\\') ss << "\\\\";
                    else if (c == '"') ss << "\\\"";
                    else if (c == '\r') continue;
                    else ss << c;
                }
            }
            ss << "\"\n    }";
        }
        ss << "\n  ]\n}";
        embedded_rtl_snapshot = ss.str();
    }

    void write_header() {
        if (!is_open) return;
        if (embedded_rtl_snapshot.empty()) {
            // Automatically detect filelist in working directory if available
            std::ifstream fl("filelist.f");
            if (fl.is_open()) {
                fl.close();
                embed_rtl_filelist("filelist.f");
            } else {
                std::ifstream fl_wsl("filelist_wsl.f");
                if (fl_wsl.is_open()) {
                    fl_wsl.close();
                    embed_rtl_filelist("filelist_wsl.f");
                }
            }
        }

        file << "$date\n   Oct 09, 2026\n$end\n";
        file << "$version\n   VC_SIM Native Simulation Engine v1.0\n$end\n";
        file << "$timescale 1ns $end\n";

        if (!embedded_rtl_snapshot.empty()) {
            file << "$comment [VC_WAVE_RTL_SNAPSHOT_BEGIN]\n";
            file << embedded_rtl_snapshot << "\n";
            file << "[VC_WAVE_RTL_SNAPSHOT_END] $end\n";
        }

        file << "$scope module top $end\n";
        for (const auto& v : vars) {
            file << "$var wire " << v.width << " " << v.id << " " << v.name;
            if (v.width > 1) file << " [" << (v.width - 1) << ":0]";
            file << " $end\n";
        }
        file << "$upscope $end\n";
        file << "$enddefinitions $end\n";
        file << "$dumpvars\n";
        for (const auto& v : vars) {
            if (v.width == 1) {
                file << "0" << v.id << "\n";
            } else {
                file << "b0 " << v.id << "\n";
            }
        }
        file << "$end\n";
    }

    void dump(double current_time, const std::string& id, uint64_t val, uint32_t width) {
        if (!is_open) return;
        if (current_time != last_time) {
            file << "#" << static_cast<uint64_t>(current_time) << "\n";
            last_time = current_time;
        }
        if (width == 1) {
            file << (val & 1) << id << "\n";
        } else {
            std::string bits = "";
            for (int i = width - 1; i >= 0; --i) {
                bits += ((val >> i) & 1) ? '1' : '0';
            }
            file << "b" << bits << " " << id << "\n";
        }
        file.flush();
    }

    void close() {
        if (is_open) {
            file.close();
            is_open = false;
        }
    }
};

} // namespace vcs

#endif // SIM_KERNEL_HPP

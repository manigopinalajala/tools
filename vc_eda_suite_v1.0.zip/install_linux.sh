#!/usr/bin/env bash
# ==============================================================================
# VC_SIM & VC_WAVE EDA SUITE - Professional Linux & WSL Installer
# ==============================================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "================================================================================"
echo "  VC_SIM & VC_WAVE EDA SUITE - LINUX / WSL INSTALLER"
echo "================================================================================"
echo ""

# Determine target directory
if [ "$EUID" -eq 0 ]; then
    INSTALL_DIR="/opt/vc_eda_suite"
    BIN_TARGET="/usr/local/bin"
    SUDO=""
else
    if command -v sudo &>/dev/null && sudo -n true 2>/dev/null; then
        echo "[*] Using sudo privileges to install suite globally into /opt/vc_eda_suite..."
        INSTALL_DIR="/opt/vc_eda_suite"
        BIN_TARGET="/usr/local/bin"
        SUDO="sudo"
    else
        echo "[*] Installing suite for current user into $HOME/.local/share/vc_eda_suite..."
        INSTALL_DIR="$HOME/.local/share/vc_eda_suite"
        BIN_TARGET="$HOME/.local/bin"
        SUDO=""
    fi
fi

echo "[*] Destination Directory : $INSTALL_DIR"
echo "[*] Command Link Directory: $BIN_TARGET"
echo ""

# Copy entire suite
$SUDO mkdir -p "$INSTALL_DIR" "$BIN_TARGET"
$SUDO cp -r "$DIR/bin" "$INSTALL_DIR/"
$SUDO cp -r "$DIR/include" "$INSTALL_DIR/"
$SUDO cp -r "$DIR/vc_wave" "$INSTALL_DIR/"
[ -d "$DIR/examples" ] && $SUDO cp -r "$DIR/examples" "$INSTALL_DIR/" || true

# Ensure permissions
$SUDO chmod +x "$INSTALL_DIR/bin/vc_sim" "$INSTALL_DIR/bin/vc_wave" "$INSTALL_DIR/bin/verdi"

# Create symlinks
$SUDO ln -sf "$INSTALL_DIR/bin/vc_sim" "$BIN_TARGET/vc_sim"
$SUDO ln -sf "$INSTALL_DIR/bin/vc_wave" "$BIN_TARGET/vc_wave"
$SUDO ln -sf "$INSTALL_DIR/bin/verdi" "$BIN_TARGET/verdi"

echo "[SUCCESS] Installed command links:"
echo "  - $BIN_TARGET/vc_sim"
echo "  - $BIN_TARGET/vc_wave"
echo "  - $BIN_TARGET/verdi (alias)"
echo ""

# Ensure user PATH includes BIN_TARGET if local
if [ "$BIN_TARGET" = "$HOME/.local/bin" ]; then
    if [[ ":$PATH:" != *":$HOME/.local/bin:"* ]]; then
        echo "[*] Appending $HOME/.local/bin to ~/.bashrc..."
        echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
        export PATH="$HOME/.local/bin:$PATH"
        echo "[NOTE] Run 'source ~/.bashrc' or open a new shell to update PATH."
    fi
fi

# Pre-flight System Dependency Checks
echo "--- System Dependency Verification ---"

# 1. Compiler check
if command -v g++ &>/dev/null; then
    echo "  [OK] C++ Compiler (g++) found: $(g++ --version | head -n1)"
else
    echo "  [WARNING] g++ is not installed. Required by vc_sim to compile models."
    echo "    To install: sudo dnf install gcc-c++ (Amazon Linux/RHEL) or sudo apt install g++ (Ubuntu)"
fi

# 2. Python check
if command -v python3 &>/dev/null; then
    echo "  [OK] Python found: $(python3 --version)"
    # Tkinter check
    if python3 -c "import tkinter" &>/dev/null; then
        echo "  [OK] Python Tkinter GUI library is installed."
    else
        echo "  [WARNING] Python Tkinter library is NOT installed (required for vc_wave GUI)."
        echo "    Install with:"
        echo "      Amazon Linux / RHEL / CentOS: sudo dnf install python3-tkinter (or sudo yum install python3-tkinter)"
        echo "      Ubuntu / Debian             : sudo apt update && sudo apt install python3-tk"
    fi
else
    echo "  [WARNING] python3 not found."
fi

echo ""
echo "================================================================================"
echo "  INSTALLATION COMPLETED SUCCESSFULLY!"
echo "================================================================================"
echo ""
echo "Quick Test Commands:"
echo "  vc_sim -help"
echo "  vc_wave"
echo ""
echo "To test the DMA SoC example:"
echo "  cd $INSTALL_DIR/examples/complex_dma_subsystem"
echo "  vc_wave dma_subsystem.vcd"
echo "================================================================================"

#!/usr/bin/env bash
# ==============================================================================
# VC_SIM & VC_WAVE EDA SUITE - Linux & WSL Installer
# ==============================================================================
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_DIR="$DIR/bin"

echo "================================================================================"
echo "  VC_SIM & VC_WAVE EDA SUITE - LINUX / WSL INSTALLER"
echo "================================================================================"
echo ""

# Ensure binaries have executable permissions
chmod +x "$BIN_DIR/vc_sim" "$BIN_DIR/vc_wave" "$BIN_DIR/verdi"

# Determine target directory
if [ "$EUID" -eq 0 ]; then
    TARGET_DIR="/usr/local/bin"
else
    if command -v sudo &>/dev/null; then
        echo "[*] Requesting sudo permissions to install globally into /usr/local/bin..."
        SUDO="sudo"
        TARGET_DIR="/usr/local/bin"
    else
        TARGET_DIR="$HOME/.local/bin"
        mkdir -p "$TARGET_DIR"
    fi
fi

echo "[*] Installing to $TARGET_DIR..."

if [ -n "$SUDO" ]; then
    $SUDO cp "$BIN_DIR/vc_sim" "$TARGET_DIR/vc_sim"
    $SUDO cp "$BIN_DIR/vc_wave" "$TARGET_DIR/vc_wave"
    $SUDO cp "$BIN_DIR/verdi" "$TARGET_DIR/verdi"
    $SUDO chmod +x "$TARGET_DIR/vc_sim" "$TARGET_DIR/vc_wave" "$TARGET_DIR/verdi"
else
    cp "$BIN_DIR/vc_sim" "$TARGET_DIR/vc_sim"
    cp "$BIN_DIR/vc_wave" "$TARGET_DIR/vc_wave"
    cp "$BIN_DIR/verdi" "$TARGET_DIR/verdi"
    chmod +x "$TARGET_DIR/vc_sim" "$TARGET_DIR/vc_wave" "$TARGET_DIR/verdi"
fi

echo ""
echo "================================================================================"
echo "  INSTALLATION COMPLETED SUCCESSFULLY!"
echo "================================================================================"
echo ""
echo "Installed commands:"
echo "  vc_wave  : Native Standalone Waveform + Auto-RTL Debug Studio"
echo "  verdi    : (Alias for vc_wave)"
echo "  vc_sim   : SystemVerilog & UVM Simulation Engine"
echo ""
echo "Try the included DMA SoC Subsystem example:"
echo "  cd $DIR/examples/complex_dma_subsystem"
echo "  make run"
echo "  vc_wave dma_subsystem.vcd"
echo "================================================================================"

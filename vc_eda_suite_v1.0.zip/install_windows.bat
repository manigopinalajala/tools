@echo off
setlocal EnableDelayedExpansion

echo ================================================================================
echo   VC_SIM ^& VC_WAVE EDA SUITE - AUTOMATED WINDOWS INSTALLER
echo ================================================================================
echo.

set "INSTALL_DIR=%~dp0"
:: Remove trailing backslash if present
if "%INSTALL_DIR:~-1%"=="\" set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"
set "BIN_DIR=%INSTALL_DIR%\bin"

if not exist "%BIN_DIR%\vc_wave.exe" (
    echo [ERROR] Cannot find bin\vc_wave.exe in "%INSTALL_DIR%".
    echo Please make sure you extracted the complete ZIP archive before running this installer.
    pause
    exit /b 1
)

echo [*] Target Installation Directory: %INSTALL_DIR%
echo [*] Adding bin directory to User PATH environment variable...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$binDir = [System.IO.Path]::GetFullPath('%BIN_DIR%'); " ^
    "$userPath = [Environment]::GetEnvironmentVariable('Path', 'User'); " ^
    "if ($userPath -split ';' -notcontains $binDir) { " ^
    "    $newPath = if ($userPath) { $userPath.TrimEnd(';') + ';' + $binDir } else { $binDir }; " ^
    "    [Environment]::SetEnvironmentVariable('Path', $newPath, 'User'); " ^
    "    Write-Host '[SUCCESS] Added to User PATH:' $binDir; " ^
    "} else { " ^
    "    Write-Host '[INFO] Directory is already present in User PATH.'; " ^
    "}"

echo.
echo [*] Creating Desktop Shortcut for VC_Wave Debugger...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
    "$ws = New-Object -ComObject WScript.Shell; " ^
    "$sc = $ws.CreateShortcut(\"$desktop\VC_Wave.lnk\"); " ^
    "$sc.TargetPath = [System.IO.Path]::GetFullPath('%BIN_DIR%\vc_wave.exe'); " ^
    "$sc.WorkingDirectory = [System.IO.Path]::GetFullPath('%INSTALL_DIR%'); " ^
    "$sc.Description = 'VC_Wave Native EDA Waveform & RTL Debugger'; " ^
    "$sc.Save(); " ^
    "Write-Host '[SUCCESS] Desktop shortcut created: VC_Wave.lnk'"

echo.
echo ================================================================================
echo   INSTALLATION COMPLETED SUCCESSFULLY!
echo ================================================================================
echo.
echo Available Commands (open a NEW Command Prompt or PowerShell):
echo   vc_wave   - Launch Native Standalone Waveform ^& RTL Debug Studio
echo   verdi     - (Alias) Launch VC_Wave Debug Studio
echo   vc_sim    - Run SystemVerilog, UVM, and Testbench Simulations
echo.
echo To try the included complex DMA SoC example:
echo   cd "%INSTALL_DIR%\examples\complex_dma_subsystem"
echo   vc_wave dma_subsystem.vcd
echo.
echo ================================================================================
pause

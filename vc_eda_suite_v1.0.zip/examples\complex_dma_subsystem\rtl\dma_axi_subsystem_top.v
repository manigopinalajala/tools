// =============================================================================
// File: dma_axi_subsystem_top.v
// Module: dma_axi_subsystem_top
// Description: Top-Level Complex System-on-Chip (SoC) Subsystem combining:
//              - AXI4-Lite Control & Status Register Bank
//              - Multi-Channel Round-Robin Bus Arbiter
//              - 1KB True Dual-Port Synchronous SRAM
//              - Autonomous DMA Burst Master Engine
//              - Synchronous Stream FIFO with Watermark Thresholds
//              - IEEE 802.3 Hardware CRC-32 Accelerator
//              - Priority Maskable Interrupt Controller
// =============================================================================

`timescale 1ns / 1ps

module dma_axi_subsystem_top #(
    parameter DATA_WIDTH = 32,
    parameter ADDR_WIDTH = 32,
    parameter SRAM_DEPTH = 256
)(
    input  wire        clk,
    input  wire        resetn,
    
    // -------------------------------------------------------------------------
    // AXI4-Lite Slave Interface (Host Control Port)
    // -------------------------------------------------------------------------
    input  wire [31:0] s_axi_awaddr,
    input  wire        s_axi_awvalid,
    output wire        s_axi_awready,
    
    input  wire [31:0] s_axi_wdata,
    input  wire [3:0]  s_axi_wstrb,
    input  wire        s_axi_wvalid,
    output wire        s_axi_wready,
    
    output wire [1:0]  s_axi_bresp,
    output wire        s_axi_bvalid,
    input  wire        s_axi_bready,
    
    input  wire [31:0] s_axi_araddr,
    input  wire        s_axi_arvalid,
    output wire        s_axi_arready,
    
    output wire [31:0] s_axi_rdata,
    output wire [1:0]  s_axi_rresp,
    output wire        s_axi_rvalid,
    input  wire        s_axi_rready,
    
    // -------------------------------------------------------------------------
    // External Streaming FIFO Read Port (Consumer / Peripheral Interface)
    // -------------------------------------------------------------------------
    input  wire        ext_fifo_rd_en,
    output wire [31:0] ext_fifo_rd_data,
    output wire        ext_fifo_empty,
    output wire        ext_fifo_almost_empty,
    
    // -------------------------------------------------------------------------
    // External Arbiter Requests (Channels 2 and 3)
    // -------------------------------------------------------------------------
    input  wire [1:0]  ext_arb_req,
    output wire [1:0]  ext_arb_grant,
    
    // -------------------------------------------------------------------------
    // Interrupt Output
    // -------------------------------------------------------------------------
    output wire        irq_out
);

    // -------------------------------------------------------------------------
    // Internal Interconnect Wires
    // -------------------------------------------------------------------------
    // DMA Control & Status Wires
    wire        dma_start;
    wire        dma_abort;
    wire [7:0]  dma_src_addr;
    wire [7:0]  dma_dst_addr;
    wire [7:0]  dma_xfer_len;
    wire        dma_busy;
    wire        dma_done;
    wire        dma_err;
    wire [7:0]  dma_words_done;

    // CRC Control & Status Wires
    wire        crc_init;
    wire [31:0] crc_seed;
    wire        crc_valid;
    wire [31:0] crc_stream_data;
    wire [31:0] crc_checksum;

    // Interrupt Control Wires
    wire [3:0]  int_imr_val;
    wire        int_imr_we;
    wire [3:0]  int_isr_clr_val;
    wire        int_isr_clr_we;
    wire [3:0]  int_imr;
    wire [3:0]  int_isr;
    wire [3:0]  int_ipr;
    wire [3:0]  irq_events;

    // FIFO Status Wires
    wire        fifo_wr_en;
    wire [31:0] fifo_wr_data;
    wire        fifo_full;
    wire        fifo_almost_full;
    wire        fifo_overflow_err;
    wire        fifo_underflow_err;
    wire [4:0]  fifo_occupancy;

    // Dual-Port SRAM Wires
    wire        sram_en_a;
    wire [3:0]  sram_we_a;
    wire [7:0]  sram_addr_a;
    wire [31:0] sram_wdata_a;
    wire [31:0] sram_rdata_a;

    wire        sram_en_b;
    wire [7:0]  sram_addr_b;
    wire [31:0] sram_rdata_b;
    wire        sram_collision;

    // Arbiter Wires
    wire [3:0]  arb_req;
    wire [3:0]  arb_grant;

    // Arbiter Channel mapping:
    // Ch 0: Host AXI
    // Ch 1: DMA Engine
    // Ch 2: External Peripheral 0
    // Ch 3: External Peripheral 1
    assign arb_req[0]     = s_axi_awvalid | s_axi_arvalid;
    assign arb_req[1]     = dma_busy;
    assign arb_req[3:2]   = ext_arb_req;
    assign ext_arb_grant  = arb_grant[3:2];

    // Interrupt mapping:
    // [0]: DMA Complete
    // [1]: DMA Error / Abort
    // [2]: FIFO Almost Full / Overflow
    // [3]: SRAM Collision Warning
    assign irq_events[0] = dma_done;
    assign irq_events[1] = dma_err;
    assign irq_events[2] = fifo_almost_full | fifo_overflow_err;
    assign irq_events[3] = sram_collision;

    // -------------------------------------------------------------------------
    // Submodule 1: AXI4-Lite Slave Interface & Register Bank
    // -------------------------------------------------------------------------
    axi_lite_slave u_axi_slave (
        .aclk            (clk),
        .aresetn         (resetn),
        
        .s_axi_awaddr    (s_axi_awaddr),
        .s_axi_awvalid   (s_axi_awvalid),
        .s_axi_awready   (s_axi_awready),
        
        .s_axi_wdata     (s_axi_wdata),
        .s_axi_wstrb     (s_axi_wstrb),
        .s_axi_wvalid    (s_axi_wvalid),
        .s_axi_wready    (s_axi_wready),
        
        .s_axi_bresp     (s_axi_bresp),
        .s_axi_bvalid    (s_axi_bvalid),
        .s_axi_bready    (s_axi_bready),
        
        .s_axi_araddr    (s_axi_araddr),
        .s_axi_arvalid   (s_axi_arvalid),
        .s_axi_arready   (s_axi_arready),
        
        .s_axi_rdata     (s_axi_rdata),
        .s_axi_rresp     (s_axi_rresp),
        .s_axi_rvalid    (s_axi_rvalid),
        .s_axi_rready    (s_axi_rready),
        
        .reg_dma_start   (dma_start),
        .reg_dma_abort   (dma_abort),
        .reg_src_addr    (dma_src_addr),
        .reg_dst_addr    (dma_dst_addr),
        .reg_xfer_len    (dma_xfer_len),
        .reg_crc_init    (crc_init),
        .reg_crc_seed    (crc_seed),
        .reg_imr_val     (int_imr_val),
        .reg_imr_we      (int_imr_we),
        .reg_isr_clr_val (int_isr_clr_val),
        .reg_isr_clr_we  (int_isr_clr_we),
        
        .dma_busy        (dma_busy),
        .dma_done        (dma_done),
        .dma_err         (dma_err),
        .dma_words_done  (dma_words_done),
        .crc_checksum    (crc_checksum),
        .int_imr         (int_imr),
        .int_isr         (int_isr),
        .int_ipr         (int_ipr),
        .fifo_full       (fifo_full),
        .fifo_empty      (ext_fifo_empty),
        .fifo_occupancy  (fifo_occupancy),
        
        .sram_en_a       (sram_en_a),
        .sram_we_a       (sram_we_a),
        .sram_addr_a     (sram_addr_a),
        .sram_wdata_a    (sram_wdata_a),
        .sram_rdata_a    (sram_rdata_a)
    );

    // -------------------------------------------------------------------------
    // Submodule 2: Round-Robin Bus Arbiter
    // -------------------------------------------------------------------------
    round_robin_arbiter u_arbiter (
        .clk             (clk),
        .resetn          (resetn),
        .req             (arb_req),
        .grant           (arb_grant),
        .any_grant       ()
    );

    // -------------------------------------------------------------------------
    // Submodule 3: True Dual-Port Synchronous SRAM (1024 Bytes / 256 Words)
    // -------------------------------------------------------------------------
    dual_port_sram #(
        .DATA_WIDTH      (32),
        .ADDR_WIDTH      (8)
    ) u_sram (
        .clk_a           (clk),
        .en_a            (sram_en_a),
        .we_a            (sram_we_a),
        .addr_a          (sram_addr_a),
        .din_a           (sram_wdata_a),
        .dout_a          (sram_rdata_a),
        
        .clk_b           (clk),
        .en_b            (sram_en_b),
        .we_b            (4'b0000),      // Port B read-only for DMA
        .addr_b          (sram_addr_b),
        .din_b           (32'd0),
        .dout_b          (sram_rdata_b),
        
        .collision_warn  (sram_collision)
    );

    // -------------------------------------------------------------------------
    // Submodule 4: Direct Memory Access (DMA) Master Engine
    // -------------------------------------------------------------------------
    dma_engine u_dma_engine (
        .clk             (clk),
        .resetn          (resetn),
        .start_cmd       (dma_start),
        .abort_cmd       (dma_abort),
        .src_addr_in     (dma_src_addr),
        .xfer_len_words  (dma_xfer_len),
        
        .busy            (dma_busy),
        .done_pulse      (dma_done),
        .error_flag      (dma_err),
        .words_transferred(dma_words_done),
        
        .sram_en         (sram_en_b),
        .sram_addr       (sram_addr_b),
        .sram_rdata      (sram_rdata_b),
        
        .fifo_wr_en      (fifo_wr_en),
        .fifo_wr_data    (fifo_wr_data),
        .fifo_full       (fifo_full),
        
        .crc_valid       (crc_valid),
        .crc_data        (crc_stream_data)
    );

    // -------------------------------------------------------------------------
    // Submodule 5: Synchronous Stream FIFO (16 Depth x 32-bit)
    // -------------------------------------------------------------------------
    sync_fifo #(
        .DATA_WIDTH      (32),
        .ADDR_WIDTH      (4),
        .ALMOST_FULL_THRESH(12),
        .ALMOST_EMPTY_THRESH(2)
    ) u_fifo (
        .clk             (clk),
        .resetn          (resetn),
        
        .wr_en           (fifo_wr_en),
        .wr_data         (fifo_wr_data),
        .full            (fifo_full),
        .almost_full     (fifo_almost_full),
        .overflow_err    (fifo_overflow_err),
        
        .rd_en           (ext_fifo_rd_en),
        .rd_data         (ext_fifo_rd_data),
        .empty           (ext_fifo_empty),
        .almost_empty    (ext_fifo_almost_empty),
        .underflow_err   (fifo_underflow_err),
        
        .occupancy       (fifo_occupancy)
    );

    // -------------------------------------------------------------------------
    // Submodule 6: Hardware CRC-32 (IEEE 802.3) Accelerator Engine
    // -------------------------------------------------------------------------
    crc32_engine u_crc32 (
        .clk             (clk),
        .resetn          (resetn),
        .init            (crc_init),
        .seed            (crc_seed),
        .data_valid      (crc_valid),
        .data_in         (crc_stream_data),
        .crc_out         (crc_checksum),
        .crc_state       ()
    );

    // -------------------------------------------------------------------------
    // Submodule 7: Priority Maskable Interrupt Controller
    // -------------------------------------------------------------------------
    interrupt_controller #(
        .NUM_IRQS        (4)
    ) u_intc (
        .clk             (clk),
        .resetn          (resetn),
        .irq_sources     (irq_events),
        .imr_write_data  (int_imr_val),
        .imr_we          (int_imr_we),
        .isr_clear_data  (int_isr_clr_val),
        .isr_clear_we    (int_isr_clr_we),
        .imr             (int_imr),
        .isr             (int_isr),
        .ipr             (int_ipr),
        .irq_out         (irq_out)
    );

endmodule

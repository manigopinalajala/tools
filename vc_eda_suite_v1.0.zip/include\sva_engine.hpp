#ifndef SVA_ENGINE_HPP
#define SVA_ENGINE_HPP

// ============================================================
//  VC_SIM Phase 2 – SystemVerilog Assertion (SVA) Engine
//  Implements: concurrent assertions, sequences, properties
//  Operators: |-> |=> ##N ##[m:n] [*N] $rose $fell $stable $past
//  Full NFA-based temporal evaluation on the discrete event queue
// ============================================================

#include <string>
#include <vector>
#include <functional>
#include <map>
#include <deque>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <memory>

namespace vcs {

// ──────────────────────────────────────────────
//  Signal History tracker (for $rose/$fell/$stable/$past)
// ──────────────────────────────────────────────
class SignalHistory {
    std::deque<std::pair<double,long long>> history_; // time -> value
    int max_depth_ = 64;
public:
    void record(double time, long long value) {
        history_.push_front({time, value});
        if ((int)history_.size() > max_depth_) history_.pop_back();
    }

    long long current() const {
        return history_.empty() ? 0 : history_.front().second;
    }

    long long past(int cycles = 1) const {
        if ((int)history_.size() > cycles) return history_[cycles].second;
        return 0;
    }

    bool rose() const {
        if (history_.size() < 2) return false;
        return history_[0].second != 0 && history_[1].second == 0;
    }

    bool fell() const {
        if (history_.size() < 2) return false;
        return history_[0].second == 0 && history_[1].second != 0;
    }

    bool stable() const {
        if (history_.size() < 2) return true;
        return history_[0].second == history_[1].second;
    }
};

// ──────────────────────────────────────────────
//  AssertionResult
// ──────────────────────────────────────────────
enum class AssertionResult { PASS, FAIL, PENDING };

// ──────────────────────────────────────────────
//  Sequence: basic building block of an SVA property
//  Evaluated as a list of (delay, condition) steps
// ──────────────────────────────────────────────
struct SequenceStep {
    int min_delay = 0, max_delay = 0;  // ##[min:max]
    std::function<bool()> condition;   // the boolean expression
    std::string label;
};

struct SVASequence {
    std::string name;
    std::vector<SequenceStep> steps;

    SVASequence& then(std::function<bool()> cond, const std::string& lbl = "",
                      int min_d = 1, int max_d = 1) {
        steps.push_back({min_d, max_d, cond, lbl});
        return *this;
    }

    // ##N shorthand (exact delay)
    SVASequence& after(int n, std::function<bool()> cond, const std::string& lbl = "") {
        return then(cond, lbl, n, n);
    }

    // ##[m:n] range
    SVASequence& after_range(int m, int n_max, std::function<bool()> cond,
                             const std::string& lbl = "") {
        return then(cond, lbl, m, n_max);
    }
};

// ──────────────────────────────────────────────
//  NFA State for one active assertion thread
// ──────────────────────────────────────────────
struct NFAThread {
    int step_index = 0;       // current step in sequence
    int cycle_wait = 0;       // remaining cycles before checking next step
    double start_time = 0.0;
    bool   failed = false;
};

// ──────────────────────────────────────────────
//  SVA Property: antecedent |-> consequent
//  or |=> (non-overlapped)
// ──────────────────────────────────────────────
struct SVAProperty {
    std::string name;
    std::string source_loc;      // file:line for reporting
    bool is_implication = true;  // |-> (overlapped) vs |=> (non-overlapped)
    bool is_assert = true;       // assert vs cover vs assume

    // Antecedent: the trigger condition
    std::function<bool()> antecedent;

    // Consequent sequence
    SVASequence consequent;

    // Active evaluation threads
    std::vector<NFAThread> threads;

    // Statistics
    int pass_count  = 0;
    int fail_count  = 0;
    int vacuous_count = 0;  // antecedent never true
    int active_count  = 0;
};

// ──────────────────────────────────────────────
//  AssertionEngine: NFA evaluator
//  Call tick() every simulated clock cycle
// ──────────────────────────────────────────────
class AssertionEngine {
    std::vector<SVAProperty*> properties_;
    std::map<std::string, SignalHistory> signals_;
    int total_pass_ = 0, total_fail_ = 0;
    double current_time_ = 0.0;

    AssertionEngine() = default;
public:
    static AssertionEngine& get() {
        static AssertionEngine inst;
        return inst;
    }

    // Register a signal for history tracking
    void register_signal(const std::string& name) {
        signals_[name]; // default-constructs if not present
    }

    // Update a signal's value (call after every DUT eval)
    void update_signal(const std::string& name, long long value) {
        signals_[name].record(current_time_, value);
    }

    // $rose / $fell / $stable / $past helpers
    bool rose(const std::string& sig) {
        auto it = signals_.find(sig);
        return it != signals_.end() && it->second.rose();
    }
    bool fell(const std::string& sig) {
        auto it = signals_.find(sig);
        return it != signals_.end() && it->second.fell();
    }
    bool stable(const std::string& sig) {
        auto it = signals_.find(sig);
        return it != signals_.end() && it->second.stable();
    }
    long long past(const std::string& sig, int n = 1) {
        auto it = signals_.find(sig);
        return it != signals_.end() ? it->second.past(n) : 0;
    }

    // Register a property
    void register_property(SVAProperty* p) {
        properties_.push_back(p);
    }

    // Evaluate one clock cycle at given sim time
    void tick(double sim_time) {
        current_time_ = sim_time;

        for (auto* prop : properties_) {
            // ── Check antecedent → spawn new thread ──
            if (prop->antecedent && prop->antecedent()) {
                NFAThread t;
                t.start_time = sim_time;
                // For non-overlapped (|=>), add 1-cycle offset
                t.cycle_wait = prop->is_implication ? 0 : 1;
                t.step_index = 0;
                prop->threads.push_back(t);
                prop->active_count++;
            }

            // ── Advance all active threads ──
            std::vector<NFAThread> next_threads;
            for (auto& thread : prop->threads) {
                if (thread.failed) continue;

                if (thread.cycle_wait > 0) {
                    thread.cycle_wait--;
                    next_threads.push_back(thread);
                    continue;
                }

                // Check current step condition
                const auto& steps = prop->consequent.steps;
                if (thread.step_index < (int)steps.size()) {
                    const auto& step = steps[thread.step_index];
                    if (step.condition && step.condition()) {
                        thread.step_index++;
                        if (thread.step_index >= (int)steps.size()) {
                            // All steps passed → assertion passes
                            prop->pass_count++;
                            total_pass_++;
                            report_pass(prop, sim_time);
                        } else {
                            // Move to next step
                            const auto& next_step = steps[thread.step_index];
                            thread.cycle_wait = next_step.min_delay - 1;
                            next_threads.push_back(thread);
                        }
                    } else {
                        // Condition failed
                        prop->fail_count++;
                        total_fail_++;
                        report_fail(prop, sim_time, thread.step_index, step.label);
                    }
                }
            }
            prop->threads = next_threads;
        }
    }

    void report_pass(const SVAProperty* p, double t) {
        std::cout << "\033[32m[T=" << std::fixed << std::setprecision(3) << t
                  << " ns] │ SVA  │ PASS │ " << p->name
                  << (p->source_loc.empty() ? "" : " (" + p->source_loc + ")")
                  << "\033[0m\n";
    }

    void report_fail(const SVAProperty* p, double t, int step, const std::string& lbl) {
        std::cout << "\033[1;31m[T=" << std::fixed << std::setprecision(3) << t
                  << " ns] │ SVA  │ FAIL │ " << p->name
                  << " at step " << step
                  << (lbl.empty() ? "" : " (" + lbl + ")")
                  << (p->source_loc.empty() ? "" : " [" + p->source_loc + "]")
                  << "\033[0m\n";
    }

    std::string generate_report() const {
        std::ostringstream oss;
        oss << "\n";
        oss << "╔══════════════════════════════════════════════════════════════════════════════╗\n";
        oss << "║              VC_SIM SVA ASSERTION REPORT (Phase 2)                          ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        oss << "║  Total Assertions Registered : " << std::setw(5) << properties_.size()
            << "                                        ║\n";
        oss << "║  Global PASS  : " << std::setw(8) << total_pass_
            << "                                                     ║\n";
        oss << "║  Global FAIL  : " << std::setw(8) << total_fail_
            << (total_fail_ > 0 ? "  ◄ ACTION REQUIRED" : "  ✓ CLEAN")
            << "\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        oss << "║  " << std::left << std::setw(28) << "Property"
            << " │ " << std::setw(6) << "Pass"
            << " │ " << std::setw(6) << "Fail"
            << " │ " << std::setw(6) << "Active"
            << " │ Status   ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        for (const auto* p : properties_) {
            oss << "║  " << std::left << std::setw(28) << p->name
                << " │ " << std::right << std::setw(6) << p->pass_count
                << " │ " << std::setw(6) << p->fail_count
                << " │ " << std::setw(6) << p->active_count
                << " │ " << (p->fail_count == 0 ? "✓ PASS  " : "✗ FAIL  ") << " ║\n";
        }
        oss << "╚══════════════════════════════════════════════════════════════════════════════╝\n";
        return oss.str();
    }

    int total_fail() const { return total_fail_; }
    int total_pass() const { return total_pass_; }
    int property_count() const { return (int)properties_.size(); }
};

// ──────────────────────────────────────────────
//  Convenience macros for C++ testbenches
// ──────────────────────────────────────────────
#define VC_SIM_ASSERT(name, antecedent_cond, ...)                          \
    do {                                                                    \
        static vcs::SVAProperty _prop_##name;                              \
        _prop_##name.name = #name;                                         \
        _prop_##name.source_loc = __FILE__ ":" + std::to_string(__LINE__); \
        _prop_##name.antecedent = [&]() { return (antecedent_cond); };    \
        _prop_##name.is_assert = true;                                     \
        vcs::AssertionEngine::get().register_property(&_prop_##name);      \
    } while(0)

#define VC_SIM_ROSE(sig)    vcs::AssertionEngine::get().rose(sig)
#define VC_SIM_FELL(sig)    vcs::AssertionEngine::get().fell(sig)
#define VC_SIM_STABLE(sig)  vcs::AssertionEngine::get().stable(sig)
#define VC_SIM_PAST(sig,n)  vcs::AssertionEngine::get().past(sig, n)

} // namespace vcs
#endif // SVA_ENGINE_HPP

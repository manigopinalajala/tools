# VC_SIM & VC_WAVE Quickstart Tutorial
### Exploring the Complex DMA & AXI4-Lite SoC Subsystem

This tutorial guides you through compiling a multi-module SystemVerilog SoC, running automated regressions, generating unified waveforms with embedded RTL, and using **`vc_wave`** for interactive debug and driver backtracing.

---

## 🏗️ The Example Design: Complex DMA Subsystem

The included example (`examples/complex_dma_subsystem`) contains a commercial-grade System-on-Chip (SoC) peripheral subsystem composed of 9 modules:

| Module | File | Function |
|---|---|---|
| **dma_axi_subsystem_top** | `dma_axi_subsystem_top.v` | Top-level SoC interconnect and port aggregation |
| **axi_lite_slave** | `axi_lite_slave.v` | 32-bit AXI4-Lite Slave Register Bank & Bridge |
| **dma_engine** | `dma_engine.v` | Autonomous Multi-Cycle DMA Burst Master FSM |
| **dual_port_sram** | `dual_port_sram.v` | 1KB True Dual-Port Synchronous SRAM with collision detection |
| **sync_fifo** | `sync_fifo.v` | Synchronous Stream FIFO with configurable watermarks |
| **crc32_engine** | `crc32_engine.v` | IEEE 802.3 Hardware CRC-32 Accelerator |
| **round_robin_arbiter** | `round_robin_arbiter.v` | 4-channel rotating-priority arbiter |
| **interrupt_controller** | `interrupt_controller.v` | 4-source priority interrupt controller with Write-1-to-Clear |
| **tb_dma_axi_subsystem** | `tb_dma_axi_subsystem.v` | Self-checking testbench executing 8 verification scenarios |

---

## 🏃 Step 1: Run Simulation & Generate Waveform

Open a terminal and navigate to the example directory:

```bash
cd examples/complex_dma_subsystem
```

### On Linux / WSL:
```bash
make clean compile run
```

### On Windows (using vc_sim directly):
```cmd
vc_sim -sverilog -f filelist.f -o simv.exe -R +dump
```

### Simulation Execution Highlights:
The simulation executes 8 comprehensive verification phases:
1. AXI4-Lite register bank identification.
2. Direct Dual-Port SRAM 32-bit byte-strobe writes and readbacks via Port A.
3. Hardware CRC-32 engine initialization.
4. Autonomous 4-word DMA burst transfer from SRAM into FIFO and CRC engine.
5. Interrupt assertion and Write-1-to-Clear clearance.
6. Synchronous FIFO stream popping and occupancy tracking.
7. CRC-32 checksum calculation verification (`0x8849ED38`).
8. Multi-channel round-robin arbiter starvation-free scheduling.

**Outputs generated:**
* `dma_subsystem.vcd`: **Unified waveform containing digital signals + complete embedded RTL snapshot!**
* `simv.log`: Detailed simulation execution transcript.
* `regression_junit.xml`: CI/CD regression report.

---

## 🔍 Step 2: Open Unified Waveform in VC_WAVE

Launch **`vc_wave`** directly with the waveform file:

```bash
vc_wave dma_subsystem.vcd
```

*(Or open `vc_wave` from the desktop shortcut and click **"📂 Open Waveform"**)*

### What Happens Instantly:
1. **Zero Prompts**: `vc_wave` parses the embedded RTL snapshot inside `dma_subsystem.vcd`.
2. **Side-by-Side nTrace + nWave**:
   * **Left Panel**: Module Hierarchy (`dma_axi_subsystem_top`), Submodules, and Port Lists.
   * **Center Panel (nTrace)**: Complete Verilog source code for the active scope with line numbers.
   * **Right Panel (nWave)**: Digital timing waveforms with signal names and live values.

---

## 🎯 Step 3: Interactive Debugging Workflows

### 1. Driver Backtracing (`Ctrl+D`)
1. In the **Signal List** (or in the waveform panel), click on any signal (for example, `dma_busy` or `irq_out`).
2. Click the **🎯 Backtrace Driver** button on the toolbar (or press `Ctrl+D`).
3. **Result**: `vc_wave` immediately jumps nTrace to the exact Verilog file and line number where that signal was assigned or driven!

### 2. Live In-Line Signal Value Annotations
1. Click anywhere on the waveform canvas to position the primary timing cursor (**$C_1$**).
2. Look at the Verilog code in nTrace:
   * Net and variable declarations immediately display their live simulation values at cursor $C_1$ in green badges (e.g., `[dma_busy: 1]`, `[current_addr: 0x02]`).
3. Press the **🟢 RTL Values: ON/OFF** toggle button to enable or disable annotations.

### 3. Measuring Timing Deltas ($\Delta$)
1. Left-click on the waveform canvas to position cursor **$C_1$**.
2. **Shift + Left-click** to position cursor **$C_2$**.
3. The toolbar dynamically computes and displays:
   ```
   C1: 210.000 ns | C2: 350.000 ns | Δ: 140.000 ns (7.143 MHz)
   ```

### 4. Hierarchy Navigation
* Click **⬇️ Down** or double-click a submodule in the **Hierarchy Tree** to step down into `u_dma_engine` or `u_sram`.
* Click **⬆️ Up** to return to the top-level SoC root.

### 5. Radix Switching
* Change the **Radix** dropdown on the toolbar between **HEX**, **BIN**, and **DEC** to re-format all buses in both the waveform window and the RTL annotations.

# Waveform Back‑Trace Support

// This header provides a minimal framework for attaching source‑code location
// information to signals that are emitted into a waveform file (VCD/FST).
// The implementation is deliberately lightweight – it stores a mapping from
// a signal identifier (string) to a struct containing the originating RTL file
// and line number.  The simulator will consult this map when writing the
// waveform and embed a `$comment` entry (VCD) or a custom attribute (FST) so
// that downstream viewers can display the source line on a back‑trace request.

#ifndef WAVE_BACKTRACE_HPP
#define WAVE_BACKTRACE_HPP

#include <string>
#include <unordered_map>

namespace vc_sim {

struct SourceLocation {
    std::string file;   // absolute or relative path to the RTL source
    int line;           // line number within the file (1‑based)
};

/**
 * @brief Global registry for signal ↔ source location mapping.
 *
 * The UVM components that drive signals will call `register_signal` during
 * elaboration.  The waveform writer queries the registry via `lookup` when
 * emitting a value change.
 */
class WaveBacktrace {
public:
    // Register a signal name with its source location.
    static void register_signal(const std::string &signal_name,
                                const SourceLocation &loc) {
        get_registry()[signal_name] = loc;
    }

    // Retrieve the location for a signal; returns nullptr if unknown.
    static const SourceLocation* lookup(const std::string &signal_name) {
        auto &reg = get_registry();
        auto it = reg.find(signal_name);
        return it != reg.end() ? &it->second : nullptr;
    }

private:
    static std::unordered_map<std::string, SourceLocation>& get_registry() {
        static std::unordered_map<std::string, SourceLocation> registry;
        return registry;
    }
};

} // namespace vc_sim

#endif // WAVE_BACKTRACE_HPP

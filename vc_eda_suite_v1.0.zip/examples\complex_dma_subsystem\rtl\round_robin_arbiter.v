// =============================================================================
// File: round_robin_arbiter.v
// Module: round_robin_arbiter
// Description: Starvation-free 4-channel Round-Robin Arbiter with rotating priority
// =============================================================================

`timescale 1ns / 1ps

module round_robin_arbiter (
    input  wire       clk,
    input  wire       resetn,
    
    // Request inputs from 4 masters
    input  wire [3:0] req,
    
    // Grant outputs to 4 masters (one-hot or all-zeros)
    output reg  [3:0] grant,
    output wire       any_grant
);

    reg [1:0] priority_ptr; // Points to the next master with highest priority

    assign any_grant = |grant;

    always @(posedge clk or negedge resetn) begin
        if (!resetn) begin
            grant        <= 4'b0000;
            priority_ptr <= 2'b00;
        end else begin
            case (priority_ptr)
                2'b00: begin
                    if      (req[0]) begin grant <= 4'b0001; priority_ptr <= 2'b01; end
                    else if (req[1]) begin grant <= 4'b0010; priority_ptr <= 2'b10; end
                    else if (req[2]) begin grant <= 4'b0100; priority_ptr <= 2'b11; end
                    else if (req[3]) begin grant <= 4'b1000; priority_ptr <= 2'b00; end
                    else             begin grant <= 4'b0000; end
                end
                2'b01: begin
                    if      (req[1]) begin grant <= 4'b0010; priority_ptr <= 2'b10; end
                    else if (req[2]) begin grant <= 4'b0100; priority_ptr <= 2'b11; end
                    else if (req[3]) begin grant <= 4'b1000; priority_ptr <= 2'b00; end
                    else if (req[0]) begin grant <= 4'b0001; priority_ptr <= 2'b01; end
                    else             begin grant <= 4'b0000; end
                end
                2'b10: begin
                    if      (req[2]) begin grant <= 4'b0100; priority_ptr <= 2'b11; end
                    else if (req[3]) begin grant <= 4'b1000; priority_ptr <= 2'b00; end
                    else if (req[0]) begin grant <= 4'b0001; priority_ptr <= 2'b01; end
                    else if (req[1]) begin grant <= 4'b0010; priority_ptr <= 2'b10; end
                    else             begin grant <= 4'b0000; end
                end
                2'b11: begin
                    if      (req[3]) begin grant <= 4'b1000; priority_ptr <= 2'b00; end
                    else if (req[0]) begin grant <= 4'b0001; priority_ptr <= 2'b01; end
                    else if (req[1]) begin grant <= 4'b0010; priority_ptr <= 2'b10; end
                    else if (req[2]) begin grant <= 4'b0100; priority_ptr <= 2'b11; end
                    else             begin grant <= 4'b0000; end
                end
            endcase
        end
    end

endmodule

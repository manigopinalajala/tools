# ==============================================================================
# VC_SIM & VC_WAVE EDA SUITE - PowerShell Installer
# ==============================================================================
$ErrorActionPreference = "Stop"

Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "   VC_SIM & VC_WAVE EDA SUITE - POWERSHELL INSTALLER" -ForegroundColor Cyan
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host ""

$installDir = $PSScriptRoot
$binDir = Join-Path $installDir "bin"

if (-not (Test-Path (Join-Path $binDir "vc_wave.exe"))) {
    Write-Error "Cannot find bin\vc_wave.exe in '$installDir'. Please make sure archive is extracted."
}

Write-Host "[*] Registering bin directory to User PATH environment variable..." -ForegroundColor Yellow
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -split ';' -notcontains $binDir) {
    $newPath = if ($userPath) { $userPath.TrimEnd(';') + ';' + $binDir } else { $binDir }
    [Environment]::SetEnvironmentVariable("Path", $newPath, "User")
    Write-Host "[SUCCESS] Added to User PATH: $binDir" -ForegroundColor Green
} else {
    Write-Host "[INFO] Directory is already present in User PATH." -ForegroundColor Gray
}

# Update current session PATH as well
$env:Path += ";$binDir"

Write-Host "`n[*] Creating Desktop Shortcut for VC_Wave..." -ForegroundColor Yellow
$desktop = [Environment]::GetFolderPath("Desktop")
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut("$desktop\VC_Wave.lnk")
$sc.TargetPath = (Join-Path $binDir "vc_wave.exe")
$sc.WorkingDirectory = $installDir
$sc.Description = "VC_Wave Native EDA Waveform & RTL Debugger"
$sc.Save()
Write-Host "[SUCCESS] Desktop shortcut created: VC_Wave.lnk" -ForegroundColor Green

Write-Host "`n================================================================================" -ForegroundColor Cyan
Write-Host "   INSTALLATION COMPLETED SUCCESSFULLY!" -ForegroundColor Green
Write-Host "================================================================================" -ForegroundColor Cyan
Write-Host "Commands available in any new terminal:"
Write-Host "  vc_wave   - Launch Native Standalone Waveform & RTL Debug Studio" -ForegroundColor White
Write-Host "  verdi     - (Alias) Launch VC_Wave Debug Studio" -ForegroundColor White
Write-Host "  vc_sim    - Run SystemVerilog & UVM Simulation Engine" -ForegroundColor White
Write-Host ""
Write-Host "Quick test command:"
Write-Host "  vc_wave (Join-Path $installDir 'examples\complex_dma_subsystem\dma_subsystem.vcd')" -ForegroundColor Yellow
Write-Host "================================================================================`n" -ForegroundColor Cyan

#ifndef WAVEFORM_GENERATOR_HPP
#define WAVEFORM_GENERATOR_HPP

// ============================================================================
//  VC_SIM Waveform Generator with Back-Tracing Support
//  ============================================================================
//  Features:
//    - Multi-format output: VCD (IEEE 1364) + FST (compressed binary)
//    - Signal dependency graph for causal back-tracing
//    - Timestamped change history ring buffer per signal
//    - Driver/source annotation (which RTL module/line caused a transition)
//    - Cone-of-influence analysis (backward from any signal at any time)
//    - Interactive query API for post-simulation back-trace
//    - Hierarchical scope management
//    - Automatic value-change suppression (no redundant dumps)
// ============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <map>
#include <deque>
#include <algorithm>
#include <functional>
#include <memory>
#include <cstdint>
#include <cassert>

namespace vcs {
namespace wave {

// ─────────────────────────────────────────────────────────────────────────────
//  Source Location — where in the RTL a signal was driven
// ─────────────────────────────────────────────────────────────────────────────
struct SourceLoc {
    std::string file;       // RTL source file path
    int         line = 0;   // 1-based line number
    std::string module;     // enclosing module name
    std::string block;      // always/assign/initial block label (optional)

    std::string to_string() const {
        std::ostringstream o;
        if (!module.empty()) o << module << " ";
        if (!file.empty())   o << file << ":" << line;
        if (!block.empty())  o << " [" << block << "]";
        return o.str();
    }

    bool empty() const { return file.empty() && module.empty(); }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Value-Change Record — a single transition captured in the history
// ─────────────────────────────────────────────────────────────────────────────
struct ValueChange {
    uint64_t    timestamp_ps;   // absolute time in picoseconds
    uint32_t    delta_cycle;    // delta step within this timestamp
    uint64_t    old_value;
    uint64_t    new_value;
    SourceLoc   driver;         // who caused this change
    uint32_t    cause_handle;   // handle of the signal that triggered this change (0 = external)
};

// ─────────────────────────────────────────────────────────────────────────────
//  Signal Descriptor — full metadata for a traced signal
// ─────────────────────────────────────────────────────────────────────────────
enum class SignalType : uint8_t {
    WIRE, REG, INTEGER, REAL, PARAMETER, CLOCK, RESET
};

struct SignalDescriptor {
    uint32_t    handle;
    std::string name;               // leaf name
    std::string full_path;          // hierarchical path (e.g. top.dut.ctrl.state)
    uint32_t    width;
    SignalType  type;
    uint64_t    current_value;
    SourceLoc   declaration;        // where the signal is declared

    // Back-trace data
    std::deque<ValueChange>     history;        // ring buffer of recent changes
    std::vector<uint32_t>       drivers;        // handles of signals that can drive this
    std::vector<uint32_t>       fanout;         // handles of signals this drives

    size_t                      max_history = 4096; // max changes to retain

    void push_change(const ValueChange& vc) {
        if (history.size() >= max_history) {
            history.pop_front();
        }
        history.push_back(vc);
        current_value = vc.new_value;
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Back-Trace Result — returned by cone-of-influence queries
// ─────────────────────────────────────────────────────────────────────────────
struct BackTraceNode {
    uint32_t    signal_handle;
    std::string signal_path;
    uint64_t    timestamp_ps;
    uint64_t    value;
    SourceLoc   driver;
    int         depth;              // distance from query root (0 = root)
};

struct BackTraceResult {
    std::string                 root_signal;
    uint64_t                    query_time_ps;
    std::vector<BackTraceNode>  trace;          // ordered root → leaf
    bool                        truncated = false;

    std::string to_string() const {
        std::ostringstream o;
        o << "\n";
        o << "╔══════════════════════════════════════════════════════════════════╗\n";
        o << "║               WAVEFORM BACK-TRACE REPORT                       ║\n";
        o << "╠══════════════════════════════════════════════════════════════════╣\n";
        o << "║  Root Signal : " << std::left << std::setw(50) << root_signal << "║\n";
        o << "║  Query Time  : " << std::setw(43) << query_time_ps
          << " ps ║\n";
        o << "╠══════════════════════════════════════════════════════════════════╣\n";

        for (const auto& node : trace) {
            std::string indent(node.depth * 2, ' ');
            std::string arrow = (node.depth == 0) ? "► " : "└─";
            o << "║ " << indent << arrow
              << std::left << std::setw(30 - node.depth * 2) << node.signal_path
              << " = 0x" << std::hex << std::setw(8) << node.value << std::dec;

            if (!node.driver.empty()) {
                o << " [" << node.driver.to_string() << "]";
            }
            // Pad to fill line
            std::string line = o.str();
            // We'll just add the closing border
            o << "\n";
        }

        if (truncated) {
            o << "║  ... (trace truncated at max depth)                            ║\n";
        }
        o << "╚══════════════════════════════════════════════════════════════════╝\n";
        return o.str();
    }
};

// ─────────────────────────────────────────────────────────────────────────────
//  VCD Writer Backend
// ─────────────────────────────────────────────────────────────────────────────
class VcdBackend {
    std::ofstream out_;
    bool          open_ = false;
    int64_t       last_time_ = -1;
    uint64_t      events_ = 0;

public:
    bool open(const std::string& path) {
        out_.open(path, std::ios::trunc);
        open_ = out_.is_open();
        return open_;
    }

    void write_header(const std::string& date, const std::string& version,
                      const std::string& timescale) {
        if (!open_) return;
        out_ << "$date\n   " << date << "\n$end\n";
        out_ << "$version\n   " << version << "\n$end\n";
        out_ << "$timescale " << timescale << " $end\n";
    }

    void scope_push(const std::string& name) {
        if (open_) out_ << "$scope module " << name << " $end\n";
    }
    void scope_pop() {
        if (open_) out_ << "$upscope $end\n";
    }

    void declare_var(const std::string& vcd_id, const std::string& name,
                     uint32_t width, const std::string& type = "wire") {
        if (!open_) return;
        out_ << "$var " << type << " " << width << " " << vcd_id << " " << name;
        if (width > 1) out_ << " [" << (width - 1) << ":0]";
        out_ << " $end\n";
    }

    void end_definitions() {
        if (open_) out_ << "$enddefinitions $end\n";
    }

    void begin_dumpvars() {
        if (open_) out_ << "$dumpvars\n";
    }
    void end_dumpvars() {
        if (open_) out_ << "$end\n";
    }

    // Emit a backtrace comment before a value change
    void emit_backtrace_comment(const std::string& signal_path,
                                const SourceLoc& driver) {
        if (!open_ || driver.empty()) return;
        out_ << "$comment backtrace " << signal_path
             << " <- " << driver.to_string() << " $end\n";
    }

    void emit_time(uint64_t time_ps) {
        if (!open_) return;
        if (static_cast<int64_t>(time_ps) != last_time_) {
            out_ << "#" << time_ps << "\n";
            last_time_ = static_cast<int64_t>(time_ps);
        }
    }

    void emit_value(const std::string& vcd_id, uint64_t val, uint32_t width) {
        if (!open_) return;
        events_++;
        if (width == 1) {
            out_ << (val & 1) << vcd_id << "\n";
        } else {
            out_ << "b";
            for (int i = static_cast<int>(width) - 1; i >= 0; --i) {
                out_ << ((val >> i) & 1);
            }
            out_ << " " << vcd_id << "\n";
        }
    }

    void close() {
        if (open_) { out_.flush(); out_.close(); open_ = false; }
    }

    uint64_t event_count() const { return events_; }
    bool is_open() const { return open_; }
};

// ─────────────────────────────────────────────────────────────────────────────
//  FST Writer Backend (compact binary)
// ─────────────────────────────────────────────────────────────────────────────
class FstBackend {
    std::ofstream out_;
    bool          open_ = false;
    uint64_t      bytes_ = 0;
    uint64_t      events_ = 0;

    enum Tag : uint8_t {
        SCOPE_PUSH  = 0x01,
        SCOPE_POP   = 0x02,
        VAR_DEF     = 0x03,
        TIME_FRAME  = 0x04,
        VALUE_CHG   = 0x05,
        BACKTRACE   = 0x06,   // NEW: back-trace metadata tag
        TRAILER     = 0xFF
    };

    void write_u8(uint8_t v)   { out_.write(reinterpret_cast<const char*>(&v), 1); bytes_ += 1; }
    void write_u16(uint16_t v) { out_.write(reinterpret_cast<const char*>(&v), 2); bytes_ += 2; }
    void write_u32(uint32_t v) { out_.write(reinterpret_cast<const char*>(&v), 4); bytes_ += 4; }
    void write_u64(uint64_t v) { out_.write(reinterpret_cast<const char*>(&v), 8); bytes_ += 8; }
    void write_str(const std::string& s) {
        write_u16(static_cast<uint16_t>(s.size()));
        out_.write(s.data(), s.size());
        bytes_ += s.size();
    }

public:
    bool open(const std::string& path) {
        out_.open(path, std::ios::binary | std::ios::trunc);
        open_ = out_.is_open();
        if (open_) {
            // Magic header: "FST_BT10" (BT = backtrace-capable)
            const char magic[8] = {'F','S','T','_','B','T','1','0'};
            out_.write(magic, 8);
            int64_t scale = -12; // 1ps
            write_u64(static_cast<uint64_t>(scale));
            bytes_ += 8;
        }
        return open_;
    }

    void scope_push(const std::string& name) {
        if (!open_) return;
        write_u8(SCOPE_PUSH);
        write_str(name);
    }
    void scope_pop() {
        if (!open_) return;
        write_u8(SCOPE_POP);
    }

    void declare_var(uint32_t handle, const std::string& name, uint32_t width, uint8_t type) {
        if (!open_) return;
        write_u8(VAR_DEF);
        write_u32(handle);
        write_u32(width);
        write_u8(type);
        write_str(name);
    }

    void emit_time(uint64_t time_ps) {
        if (!open_) return;
        write_u8(TIME_FRAME);
        write_u64(time_ps);
    }

    // Emit backtrace metadata before value change
    void emit_backtrace(uint32_t handle, uint32_t cause_handle,
                        const std::string& driver_info) {
        if (!open_) return;
        write_u8(BACKTRACE);
        write_u32(handle);
        write_u32(cause_handle);
        write_str(driver_info);
    }

    void emit_value(uint32_t handle, uint64_t val, uint32_t width) {
        if (!open_) return;
        events_++;
        write_u8(VALUE_CHG);
        write_u32(handle);
        if (width == 1) {
            write_u8(val & 1);
        } else {
            uint8_t nbytes = (width + 7) / 8;
            write_u8(nbytes);
            out_.write(reinterpret_cast<const char*>(&val), nbytes);
            bytes_ += nbytes;
        }
    }

    void close() {
        if (!open_) return;
        write_u8(TRAILER);
        out_.flush(); out_.close(); open_ = false;
    }

    uint64_t byte_count() const { return bytes_; }
    uint64_t event_count() const { return events_; }
    bool is_open() const { return open_; }
};

// ─────────────────────────────────────────────────────────────────────────────
//  Configuration
// ─────────────────────────────────────────────────────────────────────────────
struct WaveformConfig {
    bool        enable_vcd          = true;
    bool        enable_fst          = true;
    bool        enable_backtrace    = true;     // record causal chains
    bool        embed_backtrace_vcd = true;     // emit $comment in VCD
    bool        embed_backtrace_fst = true;     // emit BACKTRACE tag in FST
    std::string vcd_path            = "dump.vcd";
    std::string fst_path            = "dump.fst";
    std::string timescale           = "1ps";
    size_t      max_history         = 4096;     // per-signal change history depth
    size_t      max_backtrace_depth = 32;       // max cone-of-influence depth
};

// ─────────────────────────────────────────────────────────────────────────────
//  WaveformGenerator — the main engine
// ─────────────────────────────────────────────────────────────────────────────
class WaveformGenerator {
public:
    using Config = WaveformConfig;

private:
    Config                                  cfg_;
    VcdBackend                              vcd_;
    FstBackend                              fst_;

    // Signal database
    std::unordered_map<uint32_t, SignalDescriptor>  signals_;
    uint32_t                                        next_handle_ = 1;

    // VCD ID generation
    std::unordered_map<uint32_t, std::string>       vcd_ids_;

    // Scope stack
    std::vector<std::string>                        scope_stack_;

    // Timing
    uint64_t    current_time_ps_  = 0;
    uint32_t    current_delta_    = 0;

    // Statistics
    uint64_t    total_changes_    = 0;
    uint64_t    suppressed_       = 0;

    // Dependency graph: signal -> set of signals it depends on
    std::unordered_map<uint32_t, std::unordered_set<uint32_t>> dep_graph_;

    // Singleton
    WaveformGenerator() = default;

    // Generate a short VCD identifier from handle
    std::string make_vcd_id(uint32_t h) {
        std::string id;
        h--; // 0-based
        do {
            id += static_cast<char>('!' + (h % 94));
            h /= 94;
        } while (h > 0);
        return id;
    }

public:
    static WaveformGenerator& get() {
        static WaveformGenerator instance;
        return instance;
    }

    // ── Initialization ───────────────────────────────────────────────────
    bool initialize(const Config& cfg = Config{}) {
        cfg_ = cfg;
        bool ok = true;

        if (cfg_.enable_vcd) {
            ok &= vcd_.open(cfg_.vcd_path);
            if (ok) {
                vcd_.write_header("Generated by VC_SIM", 
                                  "VC_SIM Waveform Generator with Back-Trace V1.0",
                                  cfg_.timescale);
            }
        }
        if (cfg_.enable_fst) {
            ok &= fst_.open(cfg_.fst_path);
        }
        return ok;
    }

    // ── Scope Management ─────────────────────────────────────────────────
    void push_scope(const std::string& name) {
        scope_stack_.push_back(name);
        if (cfg_.enable_vcd) vcd_.scope_push(name);
        if (cfg_.enable_fst) fst_.scope_push(name);
    }

    void pop_scope() {
        if (!scope_stack_.empty()) scope_stack_.pop_back();
        if (cfg_.enable_vcd) vcd_.scope_pop();
        if (cfg_.enable_fst) fst_.scope_pop();
    }

    std::string current_scope_path() const {
        std::string path;
        for (const auto& s : scope_stack_) {
            if (!path.empty()) path += ".";
            path += s;
        }
        return path;
    }

    // ── Signal Registration ──────────────────────────────────────────────
    uint32_t register_signal(const std::string& name, uint32_t width = 1,
                             SignalType type = SignalType::WIRE,
                             const SourceLoc& decl = {}) {
        uint32_t h = next_handle_++;
        std::string full = current_scope_path();
        if (!full.empty()) full += ".";
        full += name;

        SignalDescriptor sig;
        sig.handle        = h;
        sig.name          = name;
        sig.full_path     = full;
        sig.width         = width;
        sig.type          = type;
        sig.current_value = 0;
        sig.declaration   = decl;
        sig.max_history   = cfg_.max_history;
        signals_[h]       = std::move(sig);

        // Generate VCD ID
        std::string vid = make_vcd_id(h);
        vcd_ids_[h] = vid;

        // Declare in backends
        std::string type_str;
        switch (type) {
            case SignalType::WIRE:      type_str = "wire"; break;
            case SignalType::REG:       type_str = "reg"; break;
            case SignalType::INTEGER:   type_str = "integer"; break;
            case SignalType::REAL:      type_str = "real"; break;
            case SignalType::PARAMETER: type_str = "parameter"; break;
            case SignalType::CLOCK:     type_str = "wire"; break;
            case SignalType::RESET:     type_str = "wire"; break;
        }
        if (cfg_.enable_vcd) vcd_.declare_var(vid, name, width, type_str);
        if (cfg_.enable_fst) fst_.declare_var(h, name, width, static_cast<uint8_t>(type));

        return h;
    }

    // ── Dependency Registration ──────────────────────────────────────────
    //  Declare that signal `driven` depends on signal `driver`.
    //  e.g., if "out = in1 + in2", call:
    //    add_dependency(out_handle, in1_handle);
    //    add_dependency(out_handle, in2_handle);
    void add_dependency(uint32_t driven_handle, uint32_t driver_handle) {
        dep_graph_[driven_handle].insert(driver_handle);
        if (signals_.count(driven_handle))
            signals_[driven_handle].drivers.push_back(driver_handle);
        if (signals_.count(driver_handle))
            signals_[driver_handle].fanout.push_back(driven_handle);
    }

    // ── Finalize Definitions ─────────────────────────────────────────────
    void finalize_header() {
        if (cfg_.enable_vcd) {
            vcd_.end_definitions();
            vcd_.begin_dumpvars();
            // Dump initial values
            for (const auto& [h, sig] : signals_) {
                vcd_.emit_value(vcd_ids_[h], sig.current_value, sig.width);
            }
            vcd_.end_dumpvars();
        }
    }

    // ── Time Advancement ─────────────────────────────────────────────────
    void set_time(uint64_t time_ps, uint32_t delta = 0) {
        if (time_ps != current_time_ps_) {
            current_delta_ = 0;
        }
        current_time_ps_ = time_ps;
        current_delta_   = delta;

        if (cfg_.enable_vcd) vcd_.emit_time(time_ps);
        if (cfg_.enable_fst) fst_.emit_time(time_ps);
    }

    void set_time_ns(double time_ns) {
        set_time(static_cast<uint64_t>(time_ns * 1000.0));
    }

    uint64_t current_time_ps() const { return current_time_ps_; }

    // ── Value Change (the core dump call) ────────────────────────────────
    //  Records a value change with optional driver attribution.
    //  Returns true if the value actually changed (not suppressed).
    bool dump_value(uint32_t handle, uint64_t new_value,
                    const SourceLoc& driver = {},
                    uint32_t cause_handle = 0) {
        auto it = signals_.find(handle);
        if (it == signals_.end()) return false;

        auto& sig = it->second;
        uint64_t masked = (sig.width >= 64) ? new_value : (new_value & ((1ULL << sig.width) - 1));

        // Suppress unchanged values
        if (masked == sig.current_value && total_changes_ > 0) {
            suppressed_++;
            return false;
        }

        // Record the change
        ValueChange vc;
        vc.timestamp_ps = current_time_ps_;
        vc.delta_cycle  = current_delta_;
        vc.old_value    = sig.current_value;
        vc.new_value    = masked;
        vc.driver       = driver;
        vc.cause_handle = cause_handle;

        sig.push_change(vc);
        total_changes_++;

        // Emit backtrace metadata
        if (cfg_.enable_backtrace) {
            if (cfg_.enable_vcd && cfg_.embed_backtrace_vcd && !driver.empty()) {
                vcd_.emit_backtrace_comment(sig.full_path, driver);
            }
            if (cfg_.enable_fst && cfg_.embed_backtrace_fst) {
                fst_.emit_backtrace(handle, cause_handle, driver.to_string());
            }
        }

        // Emit value to backends
        if (cfg_.enable_vcd) vcd_.emit_value(vcd_ids_[handle], masked, sig.width);
        if (cfg_.enable_fst) fst_.emit_value(handle, masked, sig.width);

        return true;
    }

    // ── Convenience: dump from a simulation Signal object ────────────────
    //  (integrates with sim_kernel.hpp Signal class)
    bool dump_signal(uint32_t handle, uint64_t value) {
        return dump_value(handle, value);
    }

    // ── Back-Trace Queries ───────────────────────────────────────────────

    // Find the most recent change of a signal at or before `time_ps`
    const ValueChange* find_change_at(uint32_t handle, uint64_t time_ps) const {
        auto it = signals_.find(handle);
        if (it == signals_.end()) return nullptr;

        const auto& hist = it->second.history;
        const ValueChange* best = nullptr;
        for (auto rit = hist.rbegin(); rit != hist.rend(); ++rit) {
            if (rit->timestamp_ps <= time_ps) {
                best = &(*rit);
                break;
            }
        }
        return best;
    }

    // Get the full change history for a signal
    const std::deque<ValueChange>* get_history(uint32_t handle) const {
        auto it = signals_.find(handle);
        if (it == signals_.end()) return nullptr;
        return &it->second.history;
    }

    // Perform a back-trace: walk the causal chain backwards from a signal
    // at a given time, returning the cone of influence.
    BackTraceResult backtrace(uint32_t root_handle, uint64_t time_ps) const {
        BackTraceResult result;
        auto root_it = signals_.find(root_handle);
        if (root_it == signals_.end()) return result;

        result.root_signal  = root_it->second.full_path;
        result.query_time_ps = time_ps;

        // BFS through causal chain
        struct WorkItem {
            uint32_t handle;
            uint64_t time_ps;
            int      depth;
        };

        std::deque<WorkItem> queue;
        std::unordered_set<uint64_t> visited; // handle << 32 | depth to avoid cycles

        queue.push_back({root_handle, time_ps, 0});

        while (!queue.empty()) {
            auto [h, t, d] = queue.front();
            queue.pop_front();

            if (d >= static_cast<int>(cfg_.max_backtrace_depth)) {
                result.truncated = true;
                continue;
            }

            uint64_t visit_key = (static_cast<uint64_t>(h) << 32) | static_cast<uint32_t>(d);
            if (visited.count(visit_key)) continue;
            visited.insert(visit_key);

            auto sig_it = signals_.find(h);
            if (sig_it == signals_.end()) continue;
            const auto& sig = sig_it->second;

            // Find the relevant change
            const ValueChange* vc = find_change_at(h, t);

            BackTraceNode node;
            node.signal_handle = h;
            node.signal_path   = sig.full_path;
            node.timestamp_ps  = vc ? vc->timestamp_ps : 0;
            node.value         = vc ? vc->new_value : sig.current_value;
            node.driver        = vc ? vc->driver : SourceLoc{};
            node.depth         = d;
            result.trace.push_back(node);

            // Follow the causal chain
            if (vc && vc->cause_handle != 0) {
                queue.push_back({vc->cause_handle, vc->timestamp_ps, d + 1});
            }

            // Also follow registered dependencies
            auto dep_it = dep_graph_.find(h);
            if (dep_it != dep_graph_.end()) {
                for (uint32_t dep_h : dep_it->second) {
                    queue.push_back({dep_h, t, d + 1});
                }
            }
        }

        return result;
    }

    // Backtrace by signal name (convenience)
    BackTraceResult backtrace(const std::string& signal_path, uint64_t time_ps) const {
        for (const auto& [h, sig] : signals_) {
            if (sig.full_path == signal_path || sig.name == signal_path) {
                return backtrace(h, time_ps);
            }
        }
        return {};
    }

    // ── Forward Trace (Fanout Analysis) ──────────────────────────────────
    //  Given a signal, find all signals it influences.
    std::vector<std::string> fanout_of(uint32_t handle) const {
        std::vector<std::string> result;
        auto it = signals_.find(handle);
        if (it == signals_.end()) return result;
        for (uint32_t fh : it->second.fanout) {
            auto fit = signals_.find(fh);
            if (fit != signals_.end()) {
                result.push_back(fit->second.full_path);
            }
        }
        return result;
    }

    // ── Signal Lookup ────────────────────────────────────────────────────
    uint32_t find_signal(const std::string& path) const {
        for (const auto& [h, sig] : signals_) {
            if (sig.full_path == path || sig.name == path) return h;
        }
        return 0; // not found
    }

    const SignalDescriptor* get_signal(uint32_t handle) const {
        auto it = signals_.find(handle);
        return (it != signals_.end()) ? &it->second : nullptr;
    }

    // ── Shutdown ─────────────────────────────────────────────────────────
    void close() {
        if (cfg_.enable_vcd) vcd_.close();
        if (cfg_.enable_fst) fst_.close();
    }

    // ── Summary Report ───────────────────────────────────────────────────
    std::string generate_summary() const {
        std::ostringstream o;
        uint64_t vcd_events = vcd_.event_count();
        uint64_t fst_events = fst_.event_count();
        uint64_t fst_bytes  = fst_.byte_count();

        // Count signals with backtrace data
        size_t signals_with_history = 0;
        size_t total_history_entries = 0;
        size_t signals_with_deps = 0;
        for (const auto& [h, sig] : signals_) {
            if (!sig.history.empty()) {
                signals_with_history++;
                total_history_entries += sig.history.size();
            }
            if (dep_graph_.count(h)) signals_with_deps++;
        }

        o << "\n";
        o << "╔══════════════════════════════════════════════════════════════════════════════╗\n";
        o << "║       VC_SIM WAVEFORM GENERATOR WITH BACK-TRACE — SUMMARY REPORT           ║\n";
        o << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        o << "║                                                                              ║\n";
        o << "║  SIGNAL DATABASE                                                             ║\n";
        o << "║  ├─ Total Signals Registered   : " << std::setw(8) << signals_.size()       << "                                    ║\n";
        o << "║  ├─ Signals with History        : " << std::setw(8) << signals_with_history  << "                                    ║\n";
        o << "║  ├─ Signals with Dependencies   : " << std::setw(8) << signals_with_deps    << "                                    ║\n";
        o << "║  └─ Total History Entries        : " << std::setw(8) << total_history_entries << "                                    ║\n";
        o << "║                                                                              ║\n";
        o << "║  WAVEFORM OUTPUT                                                             ║\n";
        o << "║  ├─ Value Changes Recorded      : " << std::setw(8) << total_changes_       << "                                    ║\n";
        o << "║  ├─ Unchanged Values Suppressed  : " << std::setw(8) << suppressed_          << "                                    ║\n";

        if (cfg_.enable_vcd) {
            o << "║  ├─ VCD File                    : " << std::left << std::setw(40) << cfg_.vcd_path << "  ║\n";
            o << "║  │  └─ VCD Events Written       : " << std::right << std::setw(8) << vcd_events    << "                                    ║\n";
        }
        if (cfg_.enable_fst) {
            o << "║  ├─ FST File                    : " << std::left << std::setw(40) << cfg_.fst_path << "  ║\n";
            o << "║  │  ├─ FST Events Written       : " << std::right << std::setw(8) << fst_events    << "                                    ║\n";
            o << "║  │  └─ FST Bytes Written         : " << std::setw(8) << fst_bytes  << "                                    ║\n";
        }

        o << "║                                                                              ║\n";
        o << "║  BACK-TRACE SUPPORT              : " << (cfg_.enable_backtrace ? "✓ ENABLED" : "✗ DISABLED") << "                                   ║\n";
        o << "║  ├─ VCD $comment Annotations    : " << (cfg_.embed_backtrace_vcd ? "✓ YES" : "✗ NO") << "                                       ║\n";
        o << "║  ├─ FST Backtrace Tags          : " << (cfg_.embed_backtrace_fst ? "✓ YES" : "✗ NO") << "                                       ║\n";
        o << "║  └─ Max Trace Depth              : " << std::setw(8) << cfg_.max_backtrace_depth << "                                    ║\n";
        o << "║                                                                              ║\n";
        o << "╚══════════════════════════════════════════════════════════════════════════════╝\n";

        return o.str();
    }
};

} // namespace wave
} // namespace vcs

#endif // WAVEFORM_GENERATOR_HPP

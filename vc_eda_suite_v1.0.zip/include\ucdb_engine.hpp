#ifndef UCDB_ENGINE_HPP
#define UCDB_ENGINE_HPP

// ============================================================================
//  VC_SIM Unified Coverage Database (UCDB) & urg-style Reporter
//  Commercial EDA Standard: XML/JSON Unified Coverage Format
//  Features:
//   - Covergroup, Coverpoint & Cross-Coverage metrics
//   - Line, Statement & Toggle Coverage persistence
//   - Multiple test database merging (e.g., simv_test1.ucdb + simv_test2.ucdb)
//   - HTML and XML dashboard output for Jenkins / CI/CD pipelines
// ============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <vector>
#include <map>
#include <unordered_map>
#include <memory>
#include <algorithm>
#include <cmath>

namespace vcs {
namespace ucdb {

struct BinRecord {
    std::string name;
    uint64_t count = 0;
    uint64_t target = 1;
};

struct CoverpointRecord {
    std::string name;
    std::vector<BinRecord> bins;

    double get_coverage() const {
        if (bins.empty()) return 100.0;
        size_t covered = 0;
        for (const auto& b : bins) {
            if (b.count >= b.target) covered++;
        }
        return (static_cast<double>(covered) / bins.size()) * 100.0;
    }
};

struct CrossRecord {
    std::string name;
    std::string cp1_name;
    std::string cp2_name;
    std::map<std::pair<std::string, std::string>, uint64_t> cross_bins;

    double get_coverage() const {
        if (cross_bins.empty()) return 100.0;
        size_t covered = 0;
        for (const auto& kv : cross_bins) {
            if (kv.second > 0) covered++;
        }
        return (static_cast<double>(covered) / cross_bins.size()) * 100.0;
    }
};

struct CovergroupRecord {
    std::string name;
    std::string scope;
    std::unordered_map<std::string, CoverpointRecord> coverpoints;
    std::vector<CrossRecord> crosses;

    double get_coverage() const {
        double total = 0.0;
        size_t items = coverpoints.size() + crosses.size();
        if (items == 0) return 100.0;
        for (const auto& [_, cp] : coverpoints) total += cp.get_coverage();
        for (const auto& cr : crosses) total += cr.get_coverage();
        return total / items;
    }
};

class UnifiedCoverageDB {
private:
    std::string test_name_ = "unknown_test";
    std::string seed_str_ = "1";
    double sim_time_ns_ = 0.0;

    std::unordered_map<std::string, CovergroupRecord> covergroups_;
    std::unordered_map<std::string, uint64_t> statement_hits_;
    std::unordered_map<std::string, std::pair<uint32_t, uint32_t>> toggle_hits_; // name -> {rise, fall}

    UnifiedCoverageDB() = default;

public:
    static UnifiedCoverageDB& get() {
        static UnifiedCoverageDB instance;
        return instance;
    }

    void set_session(const std::string& test, const std::string& seed, double sim_time) {
        test_name_ = test;
        seed_str_ = seed;
        sim_time_ns_ = sim_time;
    }

    void record_bin(const std::string& cg, const std::string& cp, const std::string& bin, uint64_t count = 1) {
        auto& group = covergroups_[cg];
        group.name = cg;
        auto& point = group.coverpoints[cp];
        point.name = cp;

        for (auto& b : point.bins) {
            if (b.name == bin) {
                b.count += count;
                return;
            }
        }
        point.bins.push_back({bin, count, 1});
    }

    void record_cross(const std::string& cg, const std::string& cross_name, 
                      const std::string& cp1, const std::string& bin1,
                      const std::string& cp2, const std::string& bin2) {
        auto& group = covergroups_[cg];
        CrossRecord* target = nullptr;
        for (auto& cr : group.crosses) {
            if (cr.name == cross_name) {
                target = &cr;
                break;
            }
        }
        if (!target) {
            group.crosses.push_back({cross_name, cp1, cp2, {}});
            target = &group.crosses.back();
        }
        target->cross_bins[{bin1, bin2}]++;
    }

    void record_statement(const std::string& file, int line) {
        statement_hits_[file + ":" + std::to_string(line)]++;
    }

    void record_toggle(const std::string& sig_name, bool rise, bool fall) {
        auto& t = toggle_hits_[sig_name];
        if (rise) t.first++;
        if (fall) t.second++;
    }

    double get_overall_coverage() const {
        if (covergroups_.empty()) return 100.0;
        double sum = 0.0;
        for (const auto& [_, cg] : covergroups_) sum += cg.get_coverage();
        return sum / covergroups_.size();
    }

    // Export standard XML UCDB (Universal Coverage DataBase) format
    bool export_xml(const std::string& filename = "simv.ucdb.xml") const {
        std::ofstream out(filename);
        if (!out.is_open()) return false;

        out << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        out << "<ucdb version=\"2.0\" vendor=\"VC_SIM\" tool=\"urg\">\n";
        out << "  <test name=\"" << test_name_ << "\" seed=\"" << seed_str_ << "\" time=\"" << sim_time_ns_ << "ns\">\n";
        out << "    <summary overall_coverage=\"" << std::fixed << std::setprecision(2) << get_overall_coverage() << "%\"/>\n";

        out << "    <covergroups count=\"" << covergroups_.size() << "\">\n";
        for (const auto& [name, cg] : covergroups_) {
            out << "      <covergroup name=\"" << name << "\" coverage=\"" << std::setprecision(2) << cg.get_coverage() << "%\">\n";
            for (const auto& [cp_name, cp] : cg.coverpoints) {
                out << "        <coverpoint name=\"" << cp_name << "\" coverage=\"" << cp.get_coverage() << "%\">\n";
                for (const auto& bin : cp.bins) {
                    out << "          <bin name=\"" << bin.name << "\" count=\"" << bin.count << "\" target=\"" << bin.target << "\"/>\n";
                }
                out << "        </coverpoint>\n";
            }
            for (const auto& cr : cg.crosses) {
                out << "        <cross name=\"" << cr.name << "\" coverage=\"" << cr.get_coverage() << "%\">\n";
                for (const auto& [pair, count] : cr.cross_bins) {
                    out << "          <cross_bin b1=\"" << pair.first << "\" b2=\"" << pair.second << "\" count=\"" << count << "\"/>\n";
                }
                out << "        </cross>\n";
            }
            out << "      </covergroup>\n";
        }
        out << "    </covergroups>\n";

        out << "    <toggle_coverage signals=\"" << toggle_hits_.size() << "\">\n";
        for (const auto& [sig, toggles] : toggle_hits_) {
            out << "      <signal name=\"" << sig << "\" rise=\"" << toggles.first << "\" fall=\"" << toggles.second << "\"/>\n";
        }
        out << "    </toggle_coverage>\n";

        out << "  </test>\n";
        out << "</ucdb>\n";
        return true;
    }

    // Merge multiple UCDB files (urg -dir test1.ucdb -dir test2.ucdb)
    bool merge_ucdb_xml(const std::string& input_xml) {
        // Lightweight parser to merge counts from other test runs
        std::ifstream in(input_xml);
        if (!in.is_open()) return false;
        std::string line;
        std::string current_cg, current_cp;
        while (std::getline(in, line)) {
            size_t cg_pos = line.find("<covergroup name=\"");
            if (cg_pos != std::string::npos) {
                size_t q2 = line.find("\"", cg_pos + 18);
                current_cg = line.substr(cg_pos + 18, q2 - (cg_pos + 18));
            }
            size_t cp_pos = line.find("<coverpoint name=\"");
            if (cp_pos != std::string::npos) {
                size_t q2 = line.find("\"", cp_pos + 18);
                current_cp = line.substr(cp_pos + 18, q2 - (cp_pos + 18));
            }
            size_t bin_pos = line.find("<bin name=\"");
            if (bin_pos != std::string::npos && !current_cg.empty() && !current_cp.empty()) {
                size_t q2 = line.find("\"", bin_pos + 11);
                std::string bname = line.substr(bin_pos + 11, q2 - (bin_pos + 11));
                size_t cnt_pos = line.find("count=\"", q2);
                if (cnt_pos != std::string::npos) {
                    size_t q4 = line.find("\"", cnt_pos + 7);
                    uint64_t cnt = std::stoull(line.substr(cnt_pos + 7, q4 - (cnt_pos + 7)));
                    record_bin(current_cg, current_cp, bname, cnt);
                }
            }
        }
        return true;
    }

    // Generate commercial style URG text report
    std::string generate_urg_report() const {
        std::ostringstream oss;
        oss << "\n";
        oss << "╔══════════════════════════════════════════════════════════════════════════════╗\n";
        oss << "║          VC_SIM UNIFIED COVERAGE REPORT GENERATOR (urg)                      ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        oss << "║  Target Test Session        : " << std::left << std::setw(44) << test_name_ << "   ║\n";
        oss << "║  Random PRNG Seed           : " << std::setw(44) << seed_str_ << "   ║\n";
        oss << "║  Total Functional Coverage  : " << std::fixed << std::setprecision(2) << std::setw(6) << get_overall_coverage() << "%                                          ║\n";
        oss << "╠══════════════════════════════════════════════════════════════════════════════╣\n";
        oss << "║  Covergroup Name           │ Coverpoints │ Crosses │ Score (%) │ Status       ║\n";
        oss << "╠════════════════════════════╪═════════════╪═════════╪═══════════╪══════════════╣\n";

        for (const auto& [name, cg] : covergroups_) {
            double score = cg.get_coverage();
            std::string status = (score >= 100.0) ? "✓ REACHED" : (score >= 80.0 ? "• ACCEPTABLE" : "✗ INCOMPLETE");
            oss << "║  " << std::left << std::setw(26) << name
                << "│ " << std::right << std::setw(11) << cg.coverpoints.size()
                << " │ " << std::setw(7) << cg.crosses.size()
                << " │ " << std::fixed << std::setprecision(2) << std::setw(8) << score << "%"
                << " │ " << std::left << std::setw(13) << status << "║\n";
        }
        oss << "╚══════════════════════════════════════════════════════════════════════════════╝\n";
        return oss.str();
    }
};

} // namespace ucdb
} // namespace vcs

#endif // UCDB_ENGINE_HPP
